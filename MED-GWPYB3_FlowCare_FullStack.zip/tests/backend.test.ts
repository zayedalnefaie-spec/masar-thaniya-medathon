import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createApp} from '../server/app';
import {SqliteStorage, WorkspaceStorage} from '../server/storage';
import {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';

const input = {
  ageGroup: 'adult',
  gender: 'male',
  zone: 'haram_plaza',
  mainSymptom: 'mild_cold_throat',
  severity: 2,
  redFlags: {
    difficultyBreathingSevere: false,
    chestPainSevere: false,
    lossOfConsciousness: false,
    severeBleeding: false,
    suddenConfusion: false,
    unableToWalkOrDrink: false
  }
};

async function start(storageOrFile?: WorkspaceStorage | string) {
  const {app, storage} = createApp(storageOrFile || ':memory:');
  const server = app.listen(0, '127.0.0.1');
  await new Promise<void>((r) => server.once('listening', r));
  const url = `http://127.0.0.1:${(server.address() as any).port}`;
  return {
    url,
    storage,
    stop: () =>
      new Promise<void>((r) =>
        server.close(() => {
          if (storage?.close) storage.close();
          r();
        })
      )
  };
}

async function client(url: string, cookie = '') {
  return async (path: string, body?: any) => {
    const r = await fetch(url + path, {
      headers: { cookie, 'Content-Type': 'application/json' },
      method: body ? 'POST' : 'GET',
      body: body ? JSON.stringify(body) : undefined
    });
    const setCookie = r.headers.get('set-cookie');
    cookie = setCookie?.split(';')[0] || cookie;
    return { status: r.status, data: await r.json(), cookie, setCookieHeader: setCookie };
  };
}

test('persistent isolated workspace, conflict detection, safety and atomic handover', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'masar-test-'));
  const file = join(dir, 'test.sqlite');
  let srv = await start(file);
  try {
    const a = await client(srv.url), b = await client(srv.url);
    let s = (await a('/api/state')).data;
    const firstCookie = (await a('/api/state')).cookie;
    assert.equal((await a('/api/triage', { revision: s.revision, input: { ...input, redFlags: {} } })).status, 400);
    let tri = await a('/api/triage', { revision: s.revision, input });
    assert.equal(tri.status, 200);
    assert.equal(tri.data.evaluation.acuity, 'low');
    s = tri.data.state;
    tri = await a('/api/triage', { revision: s.revision, input: { ...input, redFlags: { ...input.redFlags, suddenConfusion: 'unsure' } } });
    assert.equal(tri.data.evaluation.acuity, 'high');
    s = tri.data.state;
    assert.equal((await b('/api/state')).data.assessments.length, 0);
    assert.equal((await a('/api/actions', { revision: 0, action: 'reset' })).status, 409);
    const casualty = s.casualties.find((c: any) => c.status === 'en_route');
    const before = s.facilities.find((f: any) => f.id === casualty.assignedFacilityId);
    let r = await a('/api/actions', { revision: s.revision, action: 'status', casualtyId: casualty.id, status: 'delivered' });
    assert.equal(r.status, 200);
    s = r.data;
    let after = s.facilities.find((f: any) => f.id === before.id);
    assert.equal(after.occupiedBeds, before.occupiedBeds + 1);
    assert.equal(after.reservedBeds, before.reservedBeds - 1);
    r = await a('/api/actions', { revision: s.revision, action: 'status', casualtyId: casualty.id, status: 'delivered' });
    s = r.data;
    after = s.facilities.find((f: any) => f.id === before.id);
    assert.equal(after.occupiedBeds, before.occupiedBeds + 1);
    await srv.stop();
    srv = await start(file);
    const restored = await client(srv.url, firstCookie);
    assert.equal((await restored('/api/state')).data.assessments.length, 2);
    let current = (await restored('/api/state')).data;
    for (const f of current.facilities.filter((f: any) => f.isOperational && f.erAccepting && f.capabilities.includes('er'))) {
      current = (await restored('/api/actions', { revision: current.revision, action: 'toggleFacility', facilityId: f.id })).data;
    }
    const noEr = await restored('/api/triage', { revision: current.revision, input: { ...input, redFlags: { ...input.redFlags, chestPainSevere: true } } });
    assert.equal(noEr.status, 409);
  } finally {
    await srv.stop();
    rmSync(dir, { recursive: true, force: true });
  }
});

test('rejects cross-origin writes and unknown operations', async () => {
  const srv = await start();
  try {
    const r = await fetch(srv.url + '/api/actions', {
      method: 'POST',
      headers: { Origin: 'https://unrelated.example', 'Content-Type': 'application/json' },
      body: '{}'
    });
    assert.equal(r.status, 403);
    const c = await client(srv.url);
    const s = (await c('/api/state')).data;
    assert.equal((await c('/api/actions', { revision: s.revision, action: 'arbitrary' })).status, 400);
  } finally {
    await srv.stop();
  }
});

test('preserves records older than 24h (no automatic expiry or deletion)', async () => {
  const storage = new SqliteStorage(':memory:');
  const srv = await start(storage);
  try {
    const c = await client(srv.url);
    const initRes = await c('/api/state');
    assert.equal(initRes.status, 200);
    const sessionId = initRes.cookie.replace('masar_demo=', '');

    // Manually age the session to 36 hours in the past
    const thirtySixHoursAgo = Date.now() - 36 * 3600 * 1000;
    storage.setUpdatedForTest(sessionId, thirtySixHoursAgo);

    // Verify session still exists and has not been evicted
    const agedRes = await c('/api/state');
    assert.equal(agedRes.status, 200);
    assert.equal(agedRes.data.revision, 0);

    // Verify mutating an aged session succeeds seamlessly
    const triageRes = await c('/api/triage', { revision: 0, input });
    assert.equal(triageRes.status, 200);
    assert.equal(triageRes.data.state.revision, 1);
  } finally {
    await srv.stop();
  }
});

test('refreshes HttpOnly workspace cookie with 400-day max-age on every visit', async () => {
  const srv = await start();
  try {
    const c = await client(srv.url);
    const res1 = await c('/api/state');
    assert.equal(res1.status, 200);
    assert.ok(res1.setCookieHeader, 'set-cookie header must be present');
    assert.match(res1.setCookieHeader!, /masar_demo=[a-f0-9]{48}/);
    // 400 days in seconds = 34560000
    assert.match(res1.setCookieHeader!, /Max-Age=34560000/i);
    assert.match(res1.setCookieHeader!, /Path=\/api/i);
    assert.match(res1.setCookieHeader!, /HttpOnly/i);
    assert.match(res1.setCookieHeader!, /SameSite=Strict/i);

    // Make follow-up request with existing valid session cookie
    const res2 = await c('/api/state');
    assert.equal(res2.status, 200);
    assert.ok(res2.setCookieHeader, 'set-cookie header must be refreshed on existing session');
    assert.match(res2.setCookieHeader!, /Max-Age=34560000/i);
  } finally {
    await srv.stop();
  }
});

test('reports actual storage health and handles failed storage without silent in-memory fallback', async () => {
  // 1. Healthy storage health check
  const healthySrv = await start(':memory:');
  try {
    const healthRes = await fetch(healthySrv.url + '/api/health');
    assert.equal(healthRes.status, 200);
    const healthData = await healthRes.json();
    assert.equal(healthData.ok, true);
    assert.equal(healthData.storage, 'sqlite');
    assert.equal(healthData.connected, true);
    assert.equal(typeof healthData.latencyMs, 'number');
  } finally {
    await healthySrv.stop();
  }

  // 2. Faulty storage should fail hard with 503 on health check and 500 on mutation, NOT silently fallback
  const brokenStorage: WorkspaceStorage = {
    backend: 'firestore',
    async checkHealth() {
      return { ok: false, storage: 'firestore', connected: false, error: 'Simulated connection failure' };
    },
    async getSession() {
      throw new Error('Database unreachable');
    },
    async createSession() {
      throw new Error('Database unreachable');
    },
    async mutateSession() {
      throw new Error('Database unreachable');
    }
  };

  const brokenSrv = await start(brokenStorage);
  try {
    const healthRes = await fetch(brokenSrv.url + '/api/health');
    assert.equal(healthRes.status, 503);
    const healthData = await healthRes.json();
    assert.equal(healthData.ok, false);
    assert.equal(healthData.storage, 'firestore');
    assert.equal(healthData.connected, false);
    assert.equal(healthData.error, 'Simulated connection failure');

    // 1. Unauthenticated request against Firestore backend must be rejected with 401
    const unauthRes = await fetch(brokenSrv.url + '/api/state');
    assert.equal(unauthRes.status, 401);
    const unauthData = await unauthRes.json();
    assert.equal(unauthData.code, 'AUTH_REQUIRED');

    // 2. Authenticated request against broken storage must fail with 500, never silently fall back
    const stateRes = await fetch(brokenSrv.url + '/api/state', {
      headers: { Authorization: 'Bearer mock-auth-token-123' }
    });
    assert.equal(stateRes.status, 500);
    const stateData = await stateRes.json();
    assert.match(stateData.error, /Database unreachable/);
  } finally {
    await brokenSrv.stop();
  }
});
