import express from 'express';
import { DatabaseSync } from 'node:sqlite';
import { randomBytes, randomUUID } from 'node:crypto';
import { INITIAL_FACILITIES, INITIAL_CASUALTIES } from '../src/data/mockData';
import { evaluatePatientTriage } from '../src/utils/routingEngine';

const flags = ['difficultyBreathingSevere','chestPainSevere','lossOfConsciousness','severeBleeding','suddenConfusion','unableToWalkOrDrink'];
const capabilities = new Set(INITIAL_FACILITIES.flatMap(f=>f.capabilities));
function seed() { return { facilities: structuredClone(INITIAL_FACILITIES), casualties: structuredClone(INITIAL_CASUALTIES), isLoadBalancingApplied:false, revision:0, assessments:[] as any[], audit:[] as any[] }; }
function check(condition:any, message:string, status=400): asserts condition { if(!condition) throw Object.assign(new Error(message),{status}); }
export function createApp(filename=':memory:') {
 const db = new DatabaseSync(filename); db.exec('PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, state TEXT NOT NULL, updated INTEGER NOT NULL)');
 const app=express(); app.disable('x-powered-by'); app.use(express.json({limit:'16kb'}));
 app.get('/api/health',(_q,r)=>r.json({ok:true,storage:'sqlite',mode:'simulated-demo',version:'1.0.0'}));
 app.use('/api', (req:any,res,next)=>{
  if(!['GET','HEAD'].includes(req.method)) {
   const origin=req.headers.origin;
   if(origin && new URL(origin).host!==req.headers.host) return res.status(403).json({error:'Cross-origin writes are not allowed'});
   if(!req.is('application/json')) return res.status(415).json({error:'JSON required'});
  }
  const match=String(req.headers.cookie||'').match(/(?:^|;\s*)masar_demo=([a-f0-9]{48})(?:;|$)/);
  let id=match?.[1];
  let row=id && db.prepare('SELECT state FROM sessions WHERE id=?').get(id) as any;
  if(!row){
   // Bounded, expiring anonymous demo workspaces, never a clinical identity system.
   db.prepare('DELETE FROM sessions WHERE updated < ?').run(Date.now()-86400000);
   const count=(db.prepare('SELECT COUNT(*) AS n FROM sessions').get() as any).n;
   if(count>=1000)return res.status(503).json({error:'Demo workspace limit reached'});
   id=randomBytes(24).toString('hex');row={state:JSON.stringify(seed())};
   db.prepare('INSERT INTO sessions VALUES (?,?,?)').run(id,row.state,Date.now());
   res.cookie('masar_demo',id,{httpOnly:true,sameSite:'strict',secure:process.env.COOKIE_SECURE==='true',maxAge:86400000,path:'/api'});
  }
  req.demoId=id;res.setHeader('Cache-Control','no-store');next();
 });
 app.get('/api/state',(req:any,res)=>res.json(JSON.parse((db.prepare('SELECT state FROM sessions WHERE id=?').get(req.demoId) as any).state)));
 function mutate(req:any,work:(s:ReturnType<typeof seed>)=>any){
  db.exec('BEGIN IMMEDIATE');
  try{
   const s=JSON.parse((db.prepare('SELECT state FROM sessions WHERE id=?').get(req.demoId) as any).state);
   check(Number.isInteger(req.body.revision)&&req.body.revision===s.revision,'State changed; refresh and retry',409);
   const result=work(s);s.revision++;
   s.audit.push({id:randomUUID(),at:new Date().toISOString(),action:req.body.action||'triage'});s.audit=s.audit.slice(-200);
   db.prepare('UPDATE sessions SET state=?,updated=? WHERE id=?').run(JSON.stringify(s),Date.now(),req.demoId);
   db.exec('COMMIT');return {state:s,result};
  }catch(e){db.exec('ROLLBACK');throw e;}
 }
 app.post('/api/actions',(req:any,res,next)=>{try{
  const {state}=mutate(req,s=>{
   const b=req.body; const f=s.facilities.find(f=>f.id===b.facilityId);
   switch(b.action){
    case 'reset': {const rev=s.revision;Object.assign(s,seed(),{revision:rev});break;}
    case 'toggleFacility': check(f,'Unknown facility');f.isOperational=!f.isOperational;f.erAccepting=f.isOperational;break;
    case 'toggleCapability':check(f,'Unknown facility');check(capabilities.has(b.capability),'Unknown capability');f.capabilities=f.capabilities.includes(b.capability)?f.capabilities.filter(c=>c!==b.capability):[...f.capabilities,b.capability];break;
    case 'balance': {
     const a=s.facilities.find(f=>f.id==='fac-alfa')!,d=s.facilities.find(f=>f.id==='fac-delta')!;
     const n=s.isLoadBalancingApplied?-12:12;
     check(a.occupiedBeds-n>=0 && d.occupiedBeds+n>=0 && d.occupiedBeds+n+d.reservedBeds<=d.totalBeds && a.occupiedBeds-n+a.reservedBeds<=a.totalBeds,'Insufficient simulated capacity',409);
     a.occupiedBeds-=n;d.occupiedBeds+=n;s.isLoadBalancingApplied=!s.isLoadBalancingApplied;break;
    }
    case 'addCasualty': {
     check(s.casualties.length<100,'Demo casualty limit reached',409);const c=b.casualty;
     check(c && ['red','yellow','green','black'].includes(c.tag)&&['adult','child','elderly','unknown'].includes(c.ageGroup)&&['male','female','unknown'].includes(c.gender),'Invalid casualty');
     check(capabilities.has(c.requiredCapability)&&typeof c.radialPulsePresent==='boolean'&&['can_follow_commands','cannot_follow','unresponsive'].includes(c.mentalStatus),'Invalid casualty parameters');
     check(c.respiratoryRate===undefined || (Number.isFinite(c.respiratoryRate)&&c.respiratoryRate>=0&&c.respiratoryRate<=100),'Invalid respiratory rate');
     // Deliberately do not persist user-entered free text in a public demo.
     s.casualties.unshift({id:'DEMO-'+randomUUID().slice(0,8),incidentId:'INC-DEMO',tag:c.tag,ageGroup:c.ageGroup,gender:c.gender,requiredCapability:c.requiredCapability,radialPulsePresent:c.radialPulsePresent,mentalStatus:c.mentalStatus,respiratoryRate:c.respiratoryRate,injuryDescription:'Synthetic demonstration case',injuryDescriptionAr:'حالة محاكاة افتراضية',status:'field_triage',reportedAt:new Date().toISOString()});break;
    }
    case 'status': {
     const c=s.casualties.find(c=>c.id===b.casualtyId);check(c,'Unknown casualty',404);
     if(c.status===b.status)break;
     if(b.status==='en_route'){
      check(['field_triage','assigned'].includes(c.status),'Invalid status transition',409);
      const eligible=s.facilities.filter(x=>x.isOperational&&x.capabilities.includes(c.requiredCapability)&&(c.tag!=='red'||x.erAccepting));
      eligible.sort((a,b)=>a.travelTimeMinutes-b.travelTimeMinutes || (a.occupiedBeds+a.reservedBeds)/a.totalBeds-(b.occupiedBeds+b.reservedBeds)/b.totalBeds);
      const target=eligible[0];check(target,'No capable receiving facility; coordinator escalation required',409);
      // Never send a red case farther because the nearest capable facility is full.
      check(target.occupiedBeds+target.reservedBeds<target.totalBeds,'Nearest capable facility is full; manual emergency coordination required',409);
      c.assignedFacilityId=target.id;c.enRouteAt=new Date().toISOString();target.reservedBeds++;
     }else if(b.status==='delivered'){
      check(c.status==='en_route','Handover requires an en-route casualty',409);
      const target=s.facilities.find(x=>x.id===c.assignedFacilityId)!;check(target&&target.reservedBeds>0&&target.occupiedBeds<target.totalBeds,'Capacity conflict',409);
      target.reservedBeds--;target.occupiedBeds++;c.deliveredAt=new Date().toISOString();
     }else check(false,'Invalid status');
     c.status=b.status;break;
    }
    default:check(false,'Unknown action');
   }
  });res.json(state);
 }catch(e){next(e);}});
 app.post('/api/triage',(req:any,res,next)=>{try{
  const input=req.body.input;
  check(input&&['infant','child','adult','elderly'].includes(input.ageGroup)&&['male','female'].includes(input.gender),'Invalid demographic categories');
  check(typeof input.zone==='string'&&input.zone.length<=60&&typeof input.mainSymptom==='string'&&input.mainSymptom.length<=60,'Invalid symptom or zone');
  check(Number.isInteger(input.severity)&&input.severity>=1&&input.severity<=5,'Invalid severity');
  check(input.redFlags&&flags.every(k=>[true,false,'unsure'].includes(input.redFlags[k])),'All safety questions are required');
  const {result,state}=mutate(req,s=>{
   const result=evaluatePatientTriage(input,s.facilities);
   check(result.recommendedFacility,'No appropriate destination; emergency coordinator review required',409);
   s.assessments.push({id:randomUUID(),at:new Date().toISOString(),acuity:result.acuity,facilityId:result.recommendedFacility.id});s.assessments=s.assessments.slice(-100);
   return result;
  });res.json({evaluation:result,state});
 }catch(e){next(e);}});
 app.use('/api',(_q,r)=>r.status(404).json({error:'Unknown API route'}));
 app.use((e:any,_q:any,r:any,_n:any)=>r.status(e.status||500).json({error:e.status?e.message:'Server error'}));
 return {app,db};
}
