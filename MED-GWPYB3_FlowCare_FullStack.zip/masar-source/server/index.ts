import {createApp} from './app';
import {mkdirSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import express from 'express';
const file=process.env.DB_PATH||'data/masar.sqlite';mkdirSync(dirname(file),{recursive:true});
const {app}=createApp(file);
if(process.env.NODE_ENV==='production'){
 app.use(express.static(resolve('dist')));app.get('*',(_q,r)=>r.sendFile(resolve('dist/index.html')));
}else{
 const {createServer}=await import('vite');const vite=await createServer({server:{middlewareMode:true},appType:'spa'});app.use(vite.middlewares);
}
app.listen(Number(process.env.PORT||3000),'0.0.0.0',()=>console.log('Masar demo server ready'));
