import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { 
  Boxes, 
  Sun, 
  Moon, 
  Eye, 
  MapPin, 
  Clock, 
  Building2, 
  ShieldAlert, 
  CheckCircle2, 
  Navigation, 
  Maximize2, 
  Compass, 
  ChevronDown, 
  ChevronUp, 
  Ambulance, 
  Activity, 
  Layers, 
  Sparkles 
} from 'lucide-react';
import { Facility, Language } from '../types';

interface DigitalTwin3DProps {
  currentLang: Language;
  facilities: Facility[];
  onOpenDirections: (facility: Facility) => void;
}

// Reusable math scratchpads outside render loop to prevent garbage collection
const _targetVec = new THREE.Vector3();
const _camPosVec = new THREE.Vector3();
const _raycaster = new THREE.Raycaster();
const _mouse = new THREE.Vector2();

export const DigitalTwin3D: React.FC<DigitalTwin3DProps> = ({
  currentLang,
  facilities,
  onOpenDirections
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [selectedFacility, setSelectedFacility] = useState<Facility | null>(facilities[0] || null);
  const [isNightMode, setIsNightMode] = useState<boolean>(true);
  const [cameraView, setCameraView] = useState<'overview' | 'haram' | 'mina' | 'ambulance'>('overview');
  const [flowFilter, setFlowFilter] = useState<'all' | 'critical' | 'diverted'>('all');
  const [isControlsCollapsed, setIsControlsCollapsed] = useState<boolean>(false);

  // References for render loop coordination
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const animatedObjectsRef = useRef<{
    ambulances: THREE.Group[];
    beacons: THREE.Mesh[];
    particles: THREE.Points[];
    lights: { hemi: THREE.HemisphereLight; dir: THREE.DirectionalLight };
  } | null>(null);

  // Camera preset positions
  const CAMERA_PRESETS = {
    overview: { pos: new THREE.Vector3(0, 160, 220), target: new THREE.Vector3(0, 0, 0) },
    haram: { pos: new THREE.Vector3(-60, 45, 60), target: new THREE.Vector3(-60, 8, -10) },
    mina: { pos: new THREE.Vector3(60, 50, 70), target: new THREE.Vector3(60, 5, 0) },
    ambulance: { pos: new THREE.Vector3(10, 30, 40), target: new THREE.Vector3(0, 5, 0) }
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL to balance visual quality and CPU usage
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 1. Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(isNightMode ? 0x050b14 : 0x0f1c2e);
    scene.fog = new THREE.FogExp2(isNightMode ? 0x050b14 : 0x0f1c2e, 0.0025);

    // 2. Camera setup
    const width = container.clientWidth;
    const height = container.clientHeight || 600;
    const camera = new THREE.PerspectiveCamera(45, width / height, 1, 1200);
    camera.position.set(0, 160, 220);
    cameraRef.current = camera;

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;
    container.appendChild(renderer.domElement);

    // 4. OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI / 2.1; // Don't flip below ground
    controls.minDistance = 30;
    controls.maxDistance = 500;
    controlsRef.current = controls;

    // 5. Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x0f172a, isNightMode ? 0.6 : 1.2);
    scene.add(hemiLight);

    const dirLight = new THREE.DirectionalLight(0xfef08a, isNightMode ? 0.8 : 2.0);
    dirLight.position.set(100, 180, 80);
    dirLight.castShadow = !isSoftwareGl;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.bias = -0.0005;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 400;
    const d = 160;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    scene.add(dirLight);

    // 6. Terrain Ground & Mountains
    const groundGeo = new THREE.PlaneGeometry(600, 600, 40, 40);
    const posAttr = groundGeo.attributes.position;
    for (let i = 0; i < posAttr.count; i++) {
      const x = posAttr.getX(i);
      const y = posAttr.getY(i);
      const distFromCenter = Math.sqrt(x * x + y * y);
      if (distFromCenter > 110) {
        const heightNoise = Math.sin(x * 0.04) * Math.cos(y * 0.04) * 18 + Math.sin(x * 0.08) * 6;
        posAttr.setZ(i, Math.max(0, heightNoise));
      }
    }
    groundGeo.computeVertexNormals();

    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.9,
      metalness: 0.1,
      flatShading: true
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = !isSoftwareGl;
    scene.add(ground);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(500, 50, 0x14b8a6, 0x1e293b);
    gridHelper.position.y = 0.2;
    scene.add(gridHelper);

    // 7. Architectural Landmarks: The Holy Kaaba & Grand Piazza
    const haramGroup = new THREE.Group();
    haramGroup.position.set(-70, 0, -10);

    // Piazza floor
    const piazzaGeo = new THREE.CylinderGeometry(40, 42, 1.2, 48);
    const piazzaMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.4 });
    const piazza = new THREE.Mesh(piazzaGeo, piazzaMat);
    piazza.position.y = 0.6;
    piazza.receiveShadow = !isSoftwareGl;
    haramGroup.add(piazza);

    // The Holy Kaaba
    const kaabaGeo = new THREE.BoxGeometry(10, 12, 10);
    const kaabaMat = new THREE.MeshStandardMaterial({
      color: 0x09090b,
      roughness: 0.3,
      metalness: 0.2
    });
    const kaaba = new THREE.Mesh(kaabaGeo, kaabaMat);
    kaaba.position.y = 6.6;
    kaaba.castShadow = !isSoftwareGl;
    haramGroup.add(kaaba);

    // Gold Kiswa Band
    const bandGeo = new THREE.BoxGeometry(10.1, 1.2, 10.1);
    const bandMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.9,
      roughness: 0.2
    });
    const band = new THREE.Mesh(bandGeo, bandMat);
    band.position.y = 9.2;
    haramGroup.add(band);

    // Minarets (4 corners)
    const minaretCorners = [
      [-32, -32], [32, -32], [-32, 32], [32, 32]
    ];
    minaretCorners.forEach(([mx, mz]) => {
      const minTower = new THREE.Group();
      minTower.position.set(mx, 0, mz);
      const shaft = new THREE.Mesh(
        new THREE.CylinderGeometry(1.8, 2.4, 38, 12),
        new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.5 })
      );
      shaft.position.y = 19;
      shaft.castShadow = !isSoftwareGl;
      minTower.add(shaft);

      // Glowing Crescent Top
      const spire = new THREE.Mesh(
        new THREE.ConeGeometry(2, 6, 8),
        new THREE.MeshStandardMaterial({ color: 0x14b8a6, emissive: 0x0d9488, emissiveIntensity: 0.8 })
      );
      spire.position.y = 41;
      minTower.add(spire);
      haramGroup.add(minTower);
    });
    scene.add(haramGroup);

    // 8. Mina Valley Tent City (Procedural White Tents)
    const tentGroup = new THREE.Group();
    tentGroup.position.set(65, 0, 5);

    const tentGeo = new THREE.ConeGeometry(3.5, 4.5, 4);
    const tentMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.6,
      metalness: 0.05
    });
    const tentInstanced = new THREE.InstancedMesh(tentGeo, tentMat, 80);
    const dummy = new THREE.Object3D();
    let idx = 0;
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 10; c++) {
        const tx = (c - 5) * 8 + (Math.random() - 0.5) * 1.5;
        const tz = (r - 4) * 8 + (Math.random() - 0.5) * 1.5;
        dummy.position.set(tx, 2.25, tz);
        dummy.rotation.y = Math.PI / 4;
        dummy.updateMatrix();
        tentInstanced.setMatrixAt(idx++, dummy.matrix);
      }
    }
    tentInstanced.instanceMatrix.needsUpdate = true;
    tentInstanced.castShadow = !isSoftwareGl;
    tentInstanced.receiveShadow = !isSoftwareGl;
    tentGroup.add(tentInstanced);
    scene.add(tentGroup);

    // 9. Jamarat Multi-Level Bridge
    const jamaratGroup = new THREE.Group();
    jamaratGroup.position.set(10, 0, 20);
    for (let lvl = 0; lvl < 3; lvl++) {
      const deck = new THREE.Mesh(
        new THREE.BoxGeometry(45, 2, 14),
        new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4 })
      );
      deck.position.y = lvl * 6 + 2;
      jamaratGroup.add(deck);
    }
    // Pillars
    for (let px = -18; px <= 18; px += 18) {
      const pillar = new THREE.Mesh(
        new THREE.CylinderGeometry(1.5, 1.5, 18, 8),
        new THREE.MeshStandardMaterial({ color: 0x475569 })
      );
      pillar.position.set(px, 9, 0);
      jamaratGroup.add(pillar);
    }
    scene.add(jamaratGroup);

    // 10. Medical Facilities (3D Hospital Buildings & Interactive Beacons)
    const facilityObjects: { id: string; group: THREE.Group }[] = [];
    const beacons: THREE.Mesh[] = [];

    const facilityPositions: Record<string, [number, number]> = {
      'fac-alfa': [-45, 25], // Near Haram
      'fac-beta': [45, -30], // In Mina
      'fac-gamma': [10, 40], // Near Jamarat
      'fac-delta': [-15, -45], // Aziziyah
      'fac-specialized': [-65, -60] // Third Ring Road
    };

    facilities.filter(f => f.type !== 'virtual_hub').forEach((fac) => {
      const [fx, fz] = facilityPositions[fac.id] || [0, 0];
      const facGroup = new THREE.Group();
      facGroup.position.set(fx, 0, fz);
      (facGroup as unknown as { facilityData: Facility }).facilityData = fac;

      const occRate = fac.occupiedBeds / fac.totalBeds;
      const statusColor = occRate > 0.85 ? 0xef4444 : occRate > 0.6 ? 0xf59e0b : 0x10b981;

      // Hospital Building Structure (3-tier procedural)
      const baseBlock = new THREE.Mesh(
        new THREE.BoxGeometry(16, 12, 14),
        new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.3, metalness: 0.4 })
      );
      baseBlock.position.y = 6;
      baseBlock.castShadow = !isSoftwareGl;
      facGroup.add(baseBlock);

      const topTower = new THREE.Mesh(
        new THREE.BoxGeometry(10, 8, 10),
        new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.2 })
      );
      topTower.position.y = 16;
      facGroup.add(topTower);

      // Helipad on top
      const helipad = new THREE.Mesh(
        new THREE.CylinderGeometry(4.5, 4.5, 0.4, 16),
        new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.8 })
      );
      helipad.position.y = 20.2;
      facGroup.add(helipad);

      // Floating 3D Holographic Beacon
      const beaconGeo = new THREE.OctahedronGeometry(2.5, 0);
      const beaconMat = new THREE.MeshStandardMaterial({
        color: statusColor,
        emissive: statusColor,
        emissiveIntensity: 0.9,
        wireframe: false,
        roughness: 0.1
      });
      const beacon = new THREE.Mesh(beaconGeo, beaconMat);
      beacon.position.y = 28;
      (beacon as unknown as { facilityData: Facility }).facilityData = fac;
      facGroup.add(beacon);
      beacons.push(beacon);

      // Glowing pulsing ring
      const ringGeo = new THREE.RingGeometry(2.8, 3.4, 24);
      const ringMat = new THREE.MeshBasicMaterial({
        color: statusColor,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.7
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 28;
      facGroup.add(ring);

      scene.add(facGroup);
      facilityObjects.push({ id: fac.id, group: facGroup });
    });

    // 11. Connecting Arterial Patient Flow Highways
    const flowCurves: { curve: THREE.CatmullRomCurve3; color: number }[] = [
      // Mina to Haram Alfa (Emergency Critical Red)
      {
        curve: new THREE.CatmullRomCurve3([
          new THREE.Vector3(50, 2, 5),
          new THREE.Vector3(25, 3, 15),
          new THREE.Vector3(0, 3, 22),
          new THREE.Vector3(-30, 2, 24),
          new THREE.Vector3(-45, 2, 25)
        ]),
        color: 0xef4444
      },
      // Mina to Delta Primary Care (Redirected Low-Acuity Green)
      {
        curve: new THREE.CatmullRomCurve3([
          new THREE.Vector3(50, 2, 5),
          new THREE.Vector3(30, 2, -15),
          new THREE.Vector3(5, 2, -30),
          new THREE.Vector3(-15, 2, -45)
        ]),
        color: 0x10b981
      }
    ];

    flowCurves.forEach(({ curve, color }) => {
      const tubeGeo = new THREE.TubeGeometry(curve, 32, 0.8, 8, false);
      const tubeMat = new THREE.MeshStandardMaterial({
        color: color,
        emissive: color,
        emissiveIntensity: 0.4,
        transparent: true,
        opacity: 0.6,
        roughness: 0.2
      });
      const tube = new THREE.Mesh(tubeGeo, tubeMat);
      scene.add(tube);
    });

    // 12. Animated 3D Ambulances
    const ambulances: THREE.Group[] = [];
    for (let a = 0; a < 3; a++) {
      const ambGroup = new THREE.Group();

      // Ambulance Body
      const body = new THREE.Mesh(
        new THREE.BoxGeometry(4.5, 2.5, 2.2),
        new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 })
      );
      body.position.y = 1.6;
      ambGroup.add(body);

      // Cabin / windshield
      const cabin = new THREE.Mesh(
        new THREE.BoxGeometry(2, 1.8, 2.1),
        new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.1 })
      );
      cabin.position.set(1.4, 1.7, 0);
      ambGroup.add(cabin);

      // Flashing Emergency Siren Bar
      const siren = new THREE.Mesh(
        new THREE.BoxGeometry(0.8, 0.5, 1.6),
        new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0xdc2626, emissiveIntensity: 1.5 })
      );
      siren.position.set(0.2, 3.1, 0);
      ambGroup.add(siren);

      ambGroup.position.set(30 - a * 20, 0, 10 + a * 5);
      scene.add(ambGroup);
      ambulances.push(ambGroup);
    }

    // Save refs for animation loop
    animatedObjectsRef.current = {
      ambulances,
      beacons,
      particles: [],
      lights: { hemi: hemiLight, dir: dirLight }
    };

    // 13. Raycasting for Clicking Facilities in 3D
    const handleCanvasClick = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      _mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      _mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      _raycaster.setFromCamera(_mouse, camera);
      const intersects = _raycaster.intersectObjects(beacons, false);

      if (intersects.length > 0) {
        const hit = intersects[0].object as unknown as { facilityData?: Facility };
        if (hit.facilityData) {
          setSelectedFacility(hit.facilityData);
        }
      }
    };
    renderer.domElement.addEventListener('click', handleCanvasClick);

    // 14. Smooth Animation Loop
    let frameId = 0;
    const clock = new THREE.Clock();

    const animate = () => {
      frameId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Smoothly rotate beacons
      beacons.forEach((b, i) => {
        b.rotation.y = elapsed * 1.5 + i;
        b.position.y = 28 + Math.sin(elapsed * 2 + i) * 1.2;
      });

      // Move ambulances along curve
      if (flowCurves[0]) {
        ambulances.forEach((amb, i) => {
          const tPos = ((elapsed * 0.08) + (i * 0.33)) % 1;
          const pt = flowCurves[0].curve.getPointAt(tPos);
          const tangent = flowCurves[0].curve.getTangentAt(tPos);
          amb.position.copy(pt);
          amb.lookAt(pt.clone().add(tangent));
        });
      }

      controls.update();
      renderer.render(scene, camera);
    };

    animate();

    // Resize handler
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const w = container.clientWidth;
      const h = container.clientHeight || 600;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('click', handleCanvasClick);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update atmosphere on day/night toggle
  useEffect(() => {
    if (!sceneRef.current || !animatedObjectsRef.current) return;
    const scene = sceneRef.current;
    const { hemi, dir } = animatedObjectsRef.current.lights;

    if (isNightMode) {
      scene.background = new THREE.Color(0x050b14);
      scene.fog = new THREE.FogExp2(0x050b14, 0.0025);
      hemi.color.setHex(0x38bdf8);
      hemi.groundColor.setHex(0x0f172a);
      hemi.intensity = 0.6;
      dir.intensity = 0.8;
      dir.color.setHex(0xfef08a);
    } else {
      scene.background = new THREE.Color(0x1e293b);
      scene.fog = new THREE.FogExp2(0x1e293b, 0.002);
      hemi.color.setHex(0xffffff);
      hemi.groundColor.setHex(0x475569);
      hemi.intensity = 1.4;
      dir.intensity = 2.2;
      dir.color.setHex(0xfffbeb);
    }
  }, [isNightMode]);

  // Smooth camera transition on preset selection
  const handleSelectCameraView = (view: 'overview' | 'haram' | 'mina' | 'ambulance') => {
    setCameraView(view);
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    if (!camera || !controls) return;

    const preset = CAMERA_PRESETS[view];
    camera.position.copy(preset.pos);
    controls.target.copy(preset.target);
    controls.update();
  };

  return (
    <div className="relative w-full h-[calc(100vh-130px)] min-h-[550px] bg-slate-950 overflow-hidden flex flex-col">
      {/* Top Floating HUD: Specs & Selected Info */}
      <div className="absolute top-4 inset-x-4 z-20 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
        {/* Left/Right Brand Pill */}
        <div className="bg-slate-900/90 backdrop-blur-md px-4 py-2 rounded-2xl border border-teal-500/40 shadow-xl pointer-events-auto flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold">
            <Boxes className="w-5 h-5 animate-spin" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black text-white">التوأم الرقمي 3D</span>
              <span className="text-[10px] px-2 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                LIVE 3D TWIN
              </span>
            </div>
            <p className="text-[10px] text-slate-400">
              محاكاة ثلاثية الأبعاد للمشاعر المقدسة وتدفق المرضى والإسعافات
            </p>
          </div>
        </div>

        {/* Selected Facility Card (If active) */}
        {selectedFacility && (
          <div className="bg-slate-900/90 backdrop-blur-md p-3.5 rounded-2xl border border-slate-700 shadow-2xl pointer-events-auto flex items-center gap-4 max-w-md">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white">{selectedFacility.nameAr}</span>
                <span className={`text-[10px] px-2 py-0.2 rounded-full font-bold ${
                  (selectedFacility.occupiedBeds / selectedFacility.totalBeds) > 0.85
                    ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                }`}>
                  {Math.round((selectedFacility.occupiedBeds / selectedFacility.totalBeds) * 100)}% إشغال
                </span>
              </div>
              <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                <span>{selectedFacility.travelTimeMinutes} دقيقة وصول</span>
                <span>•</span>
                <span>{selectedFacility.totalBeds - (selectedFacility.occupiedBeds + selectedFacility.reservedBeds)} سرير متاح</span>
              </div>
            </div>

            <button
              onClick={() => onOpenDirections(selectedFacility)}
              className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shrink-0 flex items-center gap-1 shadow-md"
            >
              <span>الاتجاهات</span>
              <Navigation className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>

      {/* 3D WebGL Canvas Container */}
      <div 
        ref={mountRef} 
        className="flex-1 w-full h-full cursor-grab active:cursor-grabbing outline-none"
      />

      {/* Unified Bottom Ergonomic Control Dock (Zero Viewport Occlusion) */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 z-20 w-[95%] max-w-4xl pointer-events-auto">
        {/* Collapse / Expand Toggle Button */}
        <div className="flex justify-center -mb-3 relative z-30">
          <button
            onClick={() => setIsControlsCollapsed(!isControlsCollapsed)}
            className="px-3.5 py-1 rounded-full bg-slate-900 border border-slate-700 text-slate-300 hover:text-white text-[11px] font-bold flex items-center gap-1.5 shadow-lg transition-transform hover:scale-105"
          >
            {isControlsCollapsed ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            <span>{isControlsCollapsed ? 'إظهار لوحة التحكم 3D' : 'تصغير اللوحة (نمط السينما)'}</span>
          </button>
        </div>

        {/* The Dock Box */}
        {!isControlsCollapsed && (
          <div className="bg-slate-900/95 backdrop-blur-md p-4 rounded-3xl border border-slate-800 shadow-2xl space-y-3.5 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-3">
              
              {/* Camera Presets */}
              <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-2xl border border-slate-800">
                <span className="text-[11px] font-semibold text-slate-400 px-2">المنظور:</span>
                {[
                  { id: 'overview', label: 'المشاعر كاملة' },
                  { id: 'haram', label: 'الحرم المكي' },
                  { id: 'mina', label: 'مشعر منى' },
                  { id: 'ambulance', label: 'تتبع الإسعاف 🚑' },
                ].map((c) => (
                  <button
                    key={c.id}
                    onClick={() => handleSelectCameraView(c.id as typeof cameraView)}
                    className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                      cameraView === c.id
                        ? 'bg-teal-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {c.label}
                  </button>
                ))}
              </div>

              {/* Day / Night Atmosphere Toggle */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsNightMode(!isNightMode)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold transition-all"
                >
                  {isNightMode ? (
                    <>
                      <Moon className="w-4 h-4 text-sky-400" />
                      <span>الإضاءة الليلية</span>
                    </>
                  ) : (
                    <>
                      <Sun className="w-4 h-4 text-amber-400" />
                      <span>الإضاءة النهارية</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Quick Flow Legends & Filters */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800 text-[11px]">
              <div className="flex items-center gap-4 text-slate-400">
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-1.5 rounded-full bg-red-500" />
                  <strong className="text-white">مسار الطوارئ الحرج:</strong> تدفق مباشر لأقرب طوارئ
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-1.5 rounded-full bg-emerald-400" />
                  <strong className="text-white">مسار إعادة التوجيه الذكي:</strong> للمراكز الأولية والافتراضية
                </span>
              </div>

              <div className="text-slate-500 font-mono text-[10px]">
                انقر على أي مجسم مستشفى في المشهد ثلاثي الأبعاد لفحصه
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
