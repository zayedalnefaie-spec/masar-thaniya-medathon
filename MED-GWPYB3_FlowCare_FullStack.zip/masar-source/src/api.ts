let revision=0;
let queue:Promise<any>=Promise.resolve();
export async function loadState(){const r=await fetch('/api/state');if(!r.ok)throw new Error('Backend unavailable');const s=await r.json();revision=s.revision;return s;}
async function request(path:string,body:any){
 const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...body,revision})});
 const data=await r.json();if(!r.ok){if(r.status===409)await loadState();throw new Error(data.error||'Request failed');}
 const s=data.state||data;revision=s.revision;window.dispatchEvent(new CustomEvent('masar-state',{detail:s}));return data;
}
function serial(path:string,body:any){const p=queue.then(()=>request(path,body));queue=p.catch(()=>{});return p;}
export function action(body:any){return serial('/api/actions',body);}
export async function assess(input:any){const data=await serial('/api/triage',{input});return data.evaluation;}
export function reportError(e:any){window.dispatchEvent(new CustomEvent('masar-error',{detail:e.message||'Backend unavailable'}));}
