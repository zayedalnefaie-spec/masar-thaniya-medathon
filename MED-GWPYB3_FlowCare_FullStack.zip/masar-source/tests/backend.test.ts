import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createApp} from '../server/app';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const input={ageGroup:'adult',gender:'male',zone:'haram_plaza',mainSymptom:'mild_cold_throat',severity:2,redFlags:{difficultyBreathingSevere:false,chestPainSevere:false,lossOfConsciousness:false,severeBleeding:false,suddenConfusion:false,unableToWalkOrDrink:false}};
async function start(file=':memory:') {const {app,db}=createApp(file);const server=app.listen(0,'127.0.0.1');await new Promise<void>(r=>server.once('listening',r));const url=`http://127.0.0.1:${(server.address() as any).port}`;return {url,stop:()=>new Promise<void>(r=>server.close(()=>{db.close();r();}))};}
async function client(url:string,cookie=''){return async(path:string,body?:any)=>{const r=await fetch(url+path,{headers:{cookie,'Content-Type':'application/json'},method:body?'POST':'GET',body:body?JSON.stringify(body):undefined});cookie=r.headers.get('set-cookie')?.split(';')[0]||cookie;return {status:r.status,data:await r.json(),cookie};};}
test('persistent isolated workspace, conflict detection, safety and atomic handover',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'masar-test-'));const file=join(dir,'test.sqlite');let srv=await start(file);
 try{
 const a=await client(srv.url),b=await client(srv.url);let s=(await a('/api/state')).data;const firstCookie=(await a('/api/state')).cookie;
 assert.equal((await a('/api/triage',{revision:s.revision,input:{...input,redFlags:{}}})).status,400);
 let tri=await a('/api/triage',{revision:s.revision,input});assert.equal(tri.status,200);assert.equal(tri.data.evaluation.acuity,'low');s=tri.data.state;
 tri=await a('/api/triage',{revision:s.revision,input:{...input,redFlags:{...input.redFlags,suddenConfusion:'unsure'}}});assert.equal(tri.data.evaluation.acuity,'high');s=tri.data.state;
 assert.equal((await b('/api/state')).data.assessments.length,0);
 assert.equal((await a('/api/actions',{revision:0,action:'reset'})).status,409);
 const casualty=s.casualties.find((c:any)=>c.status==='en_route');const before=s.facilities.find((f:any)=>f.id===casualty.assignedFacilityId);
 let r=await a('/api/actions',{revision:s.revision,action:'status',casualtyId:casualty.id,status:'delivered'});assert.equal(r.status,200);s=r.data;
 let after=s.facilities.find((f:any)=>f.id===before.id);assert.equal(after.occupiedBeds,before.occupiedBeds+1);assert.equal(after.reservedBeds,before.reservedBeds-1);
 r=await a('/api/actions',{revision:s.revision,action:'status',casualtyId:casualty.id,status:'delivered'});s=r.data;after=s.facilities.find((f:any)=>f.id===before.id);assert.equal(after.occupiedBeds,before.occupiedBeds+1);
 await srv.stop();srv=await start(file);const restored=await client(srv.url,firstCookie);assert.equal((await restored('/api/state')).data.assessments.length,2);
 let current=(await restored('/api/state')).data;
 for(const f of current.facilities.filter((f:any)=>f.isOperational&&f.erAccepting&&f.capabilities.includes('er'))){current=(await restored('/api/actions',{revision:current.revision,action:'toggleFacility',facilityId:f.id})).data;}
 const noEr=await restored('/api/triage',{revision:current.revision,input:{...input,redFlags:{...input.redFlags,chestPainSevere:true}}});assert.equal(noEr.status,409);
 }finally{await srv.stop();rmSync(dir,{recursive:true,force:true});}
});
test('rejects cross-origin writes and unknown operations',async()=>{const srv=await start();try{const r=await fetch(srv.url+'/api/actions',{method:'POST',headers:{Origin:'https://unrelated.example','Content-Type':'application/json'},body:'{}'});assert.equal(r.status,403);const c=await client(srv.url);const s=(await c('/api/state')).data;assert.equal((await c('/api/actions',{revision:s.revision,action:'arbitrary'})).status,400);}finally{await srv.stop();}});
