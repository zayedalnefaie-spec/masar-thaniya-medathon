import { createApp } from './app';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import express from 'express';

if (process.env.STORAGE_BACKEND === 'sqlite') {
  const file = process.env.DB_PATH || 'data/masar.sqlite';
  mkdirSync(dirname(file), { recursive: true });
}

const { app, storage } = createApp();
console.log(`[Storage] Initialized backend: ${storage.backend}`);

if (process.env.NODE_ENV === 'production') {
  app.use(express.static(resolve('dist')));
  app.get('*', (_q, r) => r.sendFile(resolve('dist/index.html')));
} else {
  const { createServer } = await import('vite');
  const vite = await createServer({ server: { middlewareMode: true }, appType: 'spa' });
  app.use(vite.middlewares);
}

const port = Number(process.env.PORT || 3000);
app.listen(port, '0.0.0.0', () => console.log(`Masar demo server ready on port ${port} using ${storage.backend}`));
