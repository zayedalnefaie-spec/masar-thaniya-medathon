import express from 'express';
import { randomBytes } from 'node:crypto';
import { INITIAL_FACILITIES } from '../src/data/mockData';
import { evaluatePatientTriage } from '../src/utils/routingEngine';
import {
  WorkspaceStorage,
  SqliteStorage,
  FirestoreRestUserStorage,
  seedState
} from './storage';

const flags = ['difficultyBreathingSevere', 'chestPainSevere', 'lossOfConsciousness', 'severeBleeding', 'suddenConfusion', 'unableToWalkOrDrink'];
const capabilities = new Set(INITIAL_FACILITIES.flatMap((f) => f.capabilities));
const COOKIE_MAX_AGE_MS = 400 * 86400000; // 400 days in ms

function check(condition: any, message: string, status = 400): asserts condition {
  if (!condition) throw Object.assign(new Error(message), { status });
}

export function createApp(storageOrConfig?: WorkspaceStorage | string) {
  let storage: WorkspaceStorage;
  if (typeof storageOrConfig === 'string') {
    storage = new SqliteStorage(storageOrConfig);
  } else if (storageOrConfig && typeof storageOrConfig === 'object') {
    storage = storageOrConfig;
  } else if (process.env.STORAGE_BACKEND === 'sqlite') {
    storage = new SqliteStorage(process.env.DB_PATH || 'data/masar.sqlite');
  } else {
    // Durable Firestore storage via authenticated user token
    storage = new FirestoreRestUserStorage();
  }

  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '16kb' }));

  app.get('/api/health', async (_q, r) => {
    const health = await storage.checkHealth();
    const statusCode = health.ok ? 200 : 503;
    return r.status(statusCode).json({
      ok: health.ok,
      storage: storage.backend,
      connected: health.connected,
      anonymousAuthEnabled: health.anonymousAuthEnabled,
      actionRequired: health.actionRequired,
      latencyMs: health.latencyMs,
      error: health.error,
      mode: 'simulated-demo',
      version: '1.2.0'
    });
  });

  app.use('/api', async (req: any, res, next) => {
    if (!['GET', 'HEAD'].includes(req.method)) {
      const origin = req.headers.origin;
      if (origin && new URL(origin).host !== req.headers.host) {
        return res.status(403).json({ error: 'Cross-origin writes are not allowed' });
      }
      if (!req.is('application/json')) {
        return res.status(415).json({ error: 'JSON required' });
      }
    }

    try {
      const authHeader = String(req.headers.authorization || '');
      const bearerToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

      if (storage.backend === 'firestore') {
        if (!bearerToken) {
          return res.status(401).json({
            error:
              'No unauthenticated database reads/writes. Anonymous user ID token required. If anonymous sign-in is disabled, please enable Anonymous provider in Firebase Console.',
            code: 'AUTH_REQUIRED'
          });
        }
        const uid = typeof (storage as any).verifyToken === 'function'
          ? await (storage as any).verifyToken(bearerToken)
          : bearerToken;
        req.userToken = bearerToken;
        req.userUid = uid;
        req.demoId = uid;
      } else {
        // SQLite mode for local tests
        const match = String(req.headers.cookie || '').match(/(?:^|;\s*)masar_demo=([a-f0-9]{48})(?:;|$)/);
        let id = match?.[1] || (bearerToken ? bearerToken.slice(0, 48) : null);
        let record = id ? await storage.getSession(id) : null;
        if (!record) {
          id = randomBytes(24).toString('hex');
          await storage.createSession(id, seedState());
        }
        req.demoId = id;
      }

      // Renew HttpOnly SameSite secure cookie on every visit with 400-day max age
      res.cookie('masar_demo', req.demoId, {
        httpOnly: true,
        sameSite: 'strict',
        secure: process.env.COOKIE_SECURE === 'true',
        maxAge: COOKIE_MAX_AGE_MS,
        path: '/api'
      });

      res.setHeader('Cache-Control', 'no-store');
      next();
    } catch (err: any) {
      next(err);
    }
  });

  app.get('/api/state', async (req: any, res, next) => {
    try {
      let session = await storage.getSession(req.demoId, req.userToken);
      if (!session) {
        await storage.createSession(req.demoId, seedState(), req.userToken);
        session = await storage.getSession(req.demoId, req.userToken);
      }
      check(session, 'Session not found', 404);
      res.json(session.state);
    } catch (e) {
      next(e);
    }
  });

  async function mutate(req: any, work: (s: any) => any) {
    return await storage.mutateSession(
      req.demoId,
      req.body.revision,
      req.body.action || 'triage',
      work,
      req.userToken
    );
  }

  app.post('/api/actions', async (req: any, res, next) => {
    try {
      const { state } = await mutate(req, (s) => {
        const b = req.body;
        const f = s.facilities.find((fac: any) => fac.id === b.facilityId);
        switch (b.action) {
          case 'reset': {
            const rev = s.revision;
            Object.assign(s, seedState(), { revision: rev });
            break;
          }
          case 'toggleFacility':
            check(f, 'Unknown facility');
            f.isOperational = !f.isOperational;
            f.erAccepting = f.isOperational;
            break;
          case 'toggleCapability':
            check(f, 'Unknown facility');
            check(capabilities.has(b.capability), 'Unknown capability');
            f.capabilities = f.capabilities.includes(b.capability)
              ? f.capabilities.filter((c: string) => c !== b.capability)
              : [...f.capabilities, b.capability];
            break;
          case 'balance': {
            const a = s.facilities.find((fac: any) => fac.id === 'fac-alfa')!;
            const d = s.facilities.find((fac: any) => fac.id === 'fac-delta')!;
            const n = s.isLoadBalancingApplied ? -12 : 12;
            check(
              a.occupiedBeds - n >= 0 &&
                d.occupiedBeds + n >= 0 &&
                d.occupiedBeds + n + d.reservedBeds <= d.totalBeds &&
                a.occupiedBeds - n + a.reservedBeds <= a.totalBeds,
              'Insufficient simulated capacity',
              409
            );
            a.occupiedBeds -= n;
            d.occupiedBeds += n;
            s.isLoadBalancingApplied = !s.isLoadBalancingApplied;
            break;
          }
          case 'addCasualty': {
            check(s.casualties.length < 100, 'Demo casualty limit reached', 409);
            const c = b.casualty;
            check(
              c &&
                ['red', 'yellow', 'green', 'black'].includes(c.tag) &&
                ['adult', 'child', 'elderly', 'unknown'].includes(c.ageGroup) &&
                ['male', 'female', 'unknown'].includes(c.gender),
              'Invalid casualty'
            );
            check(
              capabilities.has(c.requiredCapability) &&
                typeof c.radialPulsePresent === 'boolean' &&
                ['can_follow_commands', 'cannot_follow', 'unresponsive'].includes(c.mentalStatus),
              'Invalid casualty parameters'
            );
            check(
              c.respiratoryRate === undefined ||
                (Number.isFinite(c.respiratoryRate) && c.respiratoryRate >= 0 && c.respiratoryRate <= 100),
              'Invalid respiratory rate'
            );
            s.casualties.unshift({
              id: 'DEMO-' + randomBytes(4).toString('hex'),
              incidentId: 'INC-DEMO',
              tag: c.tag,
              ageGroup: c.ageGroup,
              gender: c.gender,
              requiredCapability: c.requiredCapability,
              radialPulsePresent: c.radialPulsePresent,
              mentalStatus: c.mentalStatus,
              respiratoryRate: c.respiratoryRate,
              injuryDescription: 'Synthetic demonstration case',
              injuryDescriptionAr: 'حالة محاكاة افتراضية',
              status: 'field_triage',
              reportedAt: new Date().toISOString()
            });
            break;
          }
          case 'status': {
            const c = s.casualties.find((cas: any) => cas.id === b.casualtyId);
            check(c, 'Unknown casualty', 404);
            if (c.status === b.status) break;
            if (b.status === 'en_route') {
              check(['field_triage', 'assigned'].includes(c.status), 'Invalid status transition', 409);
              const eligible = s.facilities.filter(
                (x: any) =>
                  x.isOperational && x.capabilities.includes(c.requiredCapability) && (c.tag !== 'red' || x.erAccepting)
              );
              eligible.sort(
                (a: any, b: any) =>
                  a.travelTimeMinutes - b.travelTimeMinutes ||
                  (a.occupiedBeds + a.reservedBeds) / a.totalBeds - (b.occupiedBeds + b.reservedBeds) / b.totalBeds
              );
              const target = eligible[0];
              check(target, 'No capable receiving facility; coordinator escalation required', 409);
              check(
                target.occupiedBeds + target.reservedBeds < target.totalBeds,
                'Nearest capable facility is full; manual emergency coordination required',
                409
              );
              c.assignedFacilityId = target.id;
              c.enRouteAt = new Date().toISOString();
              target.reservedBeds++;
            } else if (b.status === 'delivered') {
              check(c.status === 'en_route', 'Handover requires an en-route casualty', 409);
              const target = s.facilities.find((x: any) => x.id === c.assignedFacilityId)!;
              check(target && target.reservedBeds > 0 && target.occupiedBeds < target.totalBeds, 'Capacity conflict', 409);
              target.reservedBeds--;
              target.occupiedBeds++;
              c.deliveredAt = new Date().toISOString();
            } else {
              check(false, 'Invalid status');
            }
            c.status = b.status;
            break;
          }
          default:
            check(false, 'Unknown action');
        }
      });
      res.json(state);
    } catch (e) {
      next(e);
    }
  });

  app.post('/api/triage', async (req: any, res, next) => {
    try {
      const input = req.body.input;
      check(
        input && ['infant', 'child', 'adult', 'elderly'].includes(input.ageGroup) && ['male', 'female'].includes(input.gender),
        'Invalid demographic categories'
      );
      check(
        typeof input.zone === 'string' &&
          input.zone.length <= 60 &&
          typeof input.mainSymptom === 'string' &&
          input.mainSymptom.length <= 60,
        'Invalid symptom or zone'
      );
      check(Number.isInteger(input.severity) && input.severity >= 1 && input.severity <= 5, 'Invalid severity');
      check(input.redFlags && flags.every((k) => [true, false, 'unsure'].includes(input.redFlags[k])), 'All safety questions are required');

      const { result, state } = await mutate(req, (s) => {
        const evalResult = evaluatePatientTriage(input, s.facilities);
        check(evalResult.recommendedFacility, 'No appropriate destination; emergency coordinator review required', 409);
        s.assessments.push({
          id: randomBytes(8).toString('hex'),
          at: new Date().toISOString(),
          acuity: evalResult.acuity,
          facilityId: evalResult.recommendedFacility.id
        });
        s.assessments = s.assessments.slice(-100);
        return evalResult;
      });
      res.json({ evaluation: result, state });
    } catch (e) {
      next(e);
    }
  });

  app.use('/api', (_q, r) => r.status(404).json({ error: 'Unknown API route' }));
  app.use((e: any, _q: any, r: any, _n: any) =>
    r.status(e.status || 500).json({ error: e.status ? e.message : e.message || 'Server error' })
  );

  return { app, storage, db: (storage as any).db };
}
