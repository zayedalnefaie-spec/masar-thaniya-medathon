import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';
import { initializeApp, getApps } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { INITIAL_FACILITIES, INITIAL_CASUALTIES } from '../src/data/mockData';

export function seedState() {
  return {
    facilities: structuredClone(INITIAL_FACILITIES),
    casualties: structuredClone(INITIAL_CASUALTIES),
    isLoadBalancingApplied: false,
    revision: 0,
    assessments: [] as any[],
    audit: [] as any[]
  };
}

export interface SessionRecord {
  id: string;
  state: any;
  revision: number;
  updated: number;
  updateTime?: string;
}

export interface StorageHealth {
  ok: boolean;
  storage: 'firestore' | 'sqlite';
  connected: boolean;
  anonymousAuthEnabled?: boolean;
  latencyMs?: number;
  error?: string;
  actionRequired?: string;
  details?: any;
}

export interface WorkspaceStorage {
  readonly backend: 'firestore' | 'sqlite';
  checkHealth(): Promise<StorageHealth>;
  getSession(id: string, userToken?: string): Promise<SessionRecord | null>;
  createSession(id: string, state: any, userToken?: string): Promise<void>;
  mutateSession(
    id: string,
    expectedRevision: number,
    actionName: string,
    work: (s: any) => any,
    userToken?: string
  ): Promise<{ state: any; result: any }>;
  close?(): Promise<void> | void;
}

export class SqliteStorage implements WorkspaceStorage {
  readonly backend = 'sqlite' as const;
  public db: DatabaseSync;

  constructor(filename = ':memory:') {
    this.db = new DatabaseSync(filename);
    this.db.exec(
      'PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, state TEXT NOT NULL, updated INTEGER NOT NULL)'
    );
  }

  async checkHealth(): Promise<StorageHealth> {
    const t0 = Date.now();
    try {
      this.db.prepare('SELECT 1').get();
      return {
        ok: true,
        storage: 'sqlite',
        connected: true,
        latencyMs: Date.now() - t0
      };
    } catch (err: any) {
      return {
        ok: false,
        storage: 'sqlite',
        connected: false,
        latencyMs: Date.now() - t0,
        error: err?.message || String(err)
      };
    }
  }

  async getSession(id: string): Promise<SessionRecord | null> {
    const row = this.db.prepare('SELECT id, state, updated FROM sessions WHERE id = ?').get(id) as any;
    if (!row) return null;
    const state = typeof row.state === 'string' ? JSON.parse(row.state) : row.state;
    return {
      id: row.id,
      state,
      revision: state.revision || 0,
      updated: row.updated
    };
  }

  async createSession(id: string, state: any): Promise<void> {
    const count = (this.db.prepare('SELECT COUNT(*) AS n FROM sessions').get() as any).n;
    if (count >= 1000) {
      const err = new Error('Demo workspace limit reached');
      (err as any).status = 503;
      throw err;
    }
    const stateStr = typeof state === 'string' ? state : JSON.stringify(state);
    this.db.prepare('INSERT INTO sessions (id, state, updated) VALUES (?, ?, ?)').run(id, stateStr, Date.now());
  }

  async mutateSession(
    id: string,
    expectedRevision: number,
    actionName: string,
    work: (s: any) => any
  ): Promise<{ state: any; result: any }> {
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const row = this.db.prepare('SELECT state FROM sessions WHERE id = ?').get(id) as any;
      if (!row) {
        throw Object.assign(new Error('Session not found'), { status: 404 });
      }
      const s = typeof row.state === 'string' ? JSON.parse(row.state) : row.state;
      if (!Number.isInteger(expectedRevision) || expectedRevision !== s.revision) {
        throw Object.assign(new Error('State changed; refresh and retry'), { status: 409 });
      }
      const result = work(s);
      s.revision++;
      s.audit = s.audit || [];
      s.audit.push({
        id: randomUUID(),
        at: new Date().toISOString(),
        action: actionName || 'triage'
      });
      s.audit = s.audit.slice(-200);
      this.db
        .prepare('UPDATE sessions SET state = ?, updated = ? WHERE id = ?')
        .run(JSON.stringify(s), Date.now(), id);
      this.db.exec('COMMIT');
      return { state: s, result };
    } catch (e) {
      this.db.exec('ROLLBACK');
      throw e;
    }
  }

  close() {
    this.db.close();
  }

  setUpdatedForTest(id: string, updated: number) {
    this.db.prepare('UPDATE sessions SET updated = ? WHERE id = ?').run(updated, id);
  }
}

export class FirestoreRestUserStorage implements WorkspaceStorage {
  readonly backend = 'firestore' as const;
  public projectId: string;
  public databaseId: string;
  public apiKey: string;
  private authAdmin: any;

  constructor(options?: { projectId?: string; databaseId?: string; apiKey?: string }) {
    this.projectId = options?.projectId || process.env.FIREBASE_PROJECT_ID || 'charismatic-century-4k6n5';
    this.databaseId =
      options?.databaseId || process.env.FIRESTORE_DATABASE_ID || 'ai-studio-3d5e00f8-b137-47a6-a26b-db3477ede1c2';
    this.apiKey = options?.apiKey || process.env.FIREBASE_API_KEY || 'AIzaSyCN5o5m2ze-jn00WKO6_gHPtuGznMPPFDA';

    const app = getApps().length ? getApps()[0] : initializeApp({ projectId: this.projectId });
    this.authAdmin = getAuth(app);
  }

  async verifyToken(token: string): Promise<string> {
    try {
      const decoded = await this.authAdmin.verifyIdToken(token);
      return decoded.uid;
    } catch (err: any) {
      throw Object.assign(new Error(`Invalid or expired Firebase Auth token: ${err.message}`), { status: 401 });
    }
  }

  private getBaseUrl(): string {
    return `https://firestore.googleapis.com/v1/projects/${this.projectId}/databases/${this.databaseId}/documents`;
  }

  async checkHealth(): Promise<StorageHealth> {
    const t0 = Date.now();
    try {
      // Check Anonymous Auth provider status via Identity Toolkit
      const authRes = await fetch(
        `https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${this.apiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ returnSecureToken: true })
        }
      );
      const authData = await authRes.json();
      const latencyMs = Date.now() - t0;

      if (!authRes.ok) {
        if (authData.error?.message === 'ADMIN_ONLY_OPERATION') {
          return {
            ok: false,
            storage: 'firestore',
            connected: true,
            anonymousAuthEnabled: false,
            latencyMs,
            error: 'Anonymous sign-in provider is disabled in Firebase Authentication.',
            actionRequired: `Please enable Anonymous sign-in provider in Firebase Console: https://console.firebase.google.com/project/${this.projectId}/authentication/providers`
          };
        }
        return {
          ok: false,
          storage: 'firestore',
          connected: false,
          latencyMs,
          error: authData.error?.message || 'Authentication service unreachable'
        };
      }

      // If test token received, test Firestore REST ping with it
      const testToken = authData.idToken;
      const testUid = authData.localId;
      const docRes = await fetch(`${this.getBaseUrl()}/demoWorkspaces/${testUid}`, {
        headers: { Authorization: `Bearer ${testToken}` }
      });

      return {
        ok: docRes.status === 200 || docRes.status === 404,
        storage: 'firestore',
        connected: true,
        anonymousAuthEnabled: true,
        latencyMs: Date.now() - t0,
        details: { projectId: this.projectId, databaseId: this.databaseId }
      };
    } catch (err: any) {
      return {
        ok: false,
        storage: 'firestore',
        connected: false,
        latencyMs: Date.now() - t0,
        error: err?.message || String(err)
      };
    }
  }

  async getSession(uid: string, userToken?: string): Promise<SessionRecord | null> {
    if (!userToken) {
      throw Object.assign(new Error('User authentication token required for workspace access'), { status: 401 });
    }
    const res = await fetch(`${this.getBaseUrl()}/demoWorkspaces/${uid}`, {
      headers: { Authorization: `Bearer ${userToken}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw Object.assign(new Error(err.error?.message || 'Firestore REST query failed'), { status: res.status });
    }
    const doc = await res.json();
    const stateStr = doc.fields?.state?.stringValue;
    const state = stateStr ? JSON.parse(stateStr) : seedState();
    return {
      id: uid,
      state,
      revision: Number(doc.fields?.revision?.integerValue ?? 0),
      updated: Number(doc.fields?.updated?.integerValue ?? Date.now()),
      updateTime: doc.updateTime
    };
  }

  async createSession(uid: string, state: any, userToken?: string): Promise<void> {
    if (!userToken) {
      throw Object.assign(new Error('User authentication token required for workspace creation'), { status: 401 });
    }
    const body = {
      fields: {
        uid: { stringValue: uid },
        revision: { integerValue: String(state.revision || 0) },
        state: { stringValue: typeof state === 'string' ? state : JSON.stringify(state) },
        updated: { integerValue: String(Date.now()) }
      }
    };
    const res = await fetch(`${this.getBaseUrl()}/demoWorkspaces/${uid}`, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${userToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw Object.assign(new Error(err.error?.message || 'Failed to create workspace in Firestore'), {
        status: res.status
      });
    }
  }

  async mutateSession(
    uid: string,
    expectedRevision: number,
    actionName: string,
    work: (s: any) => any,
    userToken?: string
  ): Promise<{ state: any; result: any }> {
    if (!userToken) {
      throw Object.assign(new Error('User authentication token required for workspace mutation'), { status: 401 });
    }

    const baseUrl = this.getBaseUrl();

    // 1. Read current document with user token
    const getRes = await fetch(`${baseUrl}/demoWorkspaces/${uid}`, {
      headers: { Authorization: `Bearer ${userToken}` }
    });

    if (!getRes.ok) {
      const err = await getRes.json().catch(() => ({}));
      throw Object.assign(new Error(err.error?.message || 'Session not found'), {
        status: getRes.status
      });
    }

    const doc = await getRes.json();
    const stateStr = doc.fields?.state?.stringValue;
    const s = stateStr ? JSON.parse(stateStr) : seedState();

    if (!Number.isInteger(expectedRevision) || expectedRevision !== s.revision) {
      throw Object.assign(new Error('State changed; refresh and retry'), { status: 409 });
    }

    // 2. Execute business logic (triage, status handover, balance)
    const result = work(s);
    s.revision++;
    s.audit = s.audit || [];
    s.audit.push({
      id: randomUUID(),
      at: new Date().toISOString(),
      action: actionName || 'triage'
    });
    s.audit = s.audit.slice(-200);

    // 3. Atomically update with precondition updateTime
    const updateBody = {
      fields: {
        uid: { stringValue: uid },
        revision: { integerValue: String(s.revision) },
        state: { stringValue: JSON.stringify(s) },
        updated: { integerValue: String(Date.now()) }
      }
    };

    const updateUrl = doc.updateTime
      ? `${baseUrl}/demoWorkspaces/${uid}?currentDocument.updateTime=${encodeURIComponent(doc.updateTime)}`
      : `${baseUrl}/demoWorkspaces/${uid}`;

    const updateRes = await fetch(updateUrl, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${userToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(updateBody)
    });

    if (!updateRes.ok) {
      const err = await updateRes.json().catch(() => ({}));
      const isConflict =
        updateRes.status === 409 ||
        err.error?.status === 'ABORTED' ||
        err.error?.status === 'FAILED_PRECONDITION';
      throw Object.assign(
        new Error(isConflict ? 'State changed; refresh and retry' : err.error?.message || 'Firestore update failed'),
        { status: isConflict ? 409 : updateRes.status }
      );
    }

    return { state: s, result };
  }
}
