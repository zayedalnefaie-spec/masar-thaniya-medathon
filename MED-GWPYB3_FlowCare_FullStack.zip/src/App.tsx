import {loadState,action,reportError,getHealth} from './api';
import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { PatientTriage } from './components/PatientTriage';
import { ThaniyaMCI } from './components/ThaniyaMCI';
import { CommandCenter } from './components/CommandCenter';
import { RoutingLab } from './components/RoutingLab';
import { NearbyFacilities } from './components/NearbyFacilities';
import { DigitalTwin3D } from './components/DigitalTwin3D';
import { JudgeDemoModal } from './components/JudgeDemoModal';
import { DirectionsModal } from './components/DirectionsModal';
import { Facility, Language, MCICasualty, CasualtyStatus } from './types';
import { INITIAL_FACILITIES, INITIAL_CASUALTIES } from './data/mockData';
import { TRANSLATIONS } from './data/translations';
import { ShieldCheck, Heart, Users, Sparkles, Building2, PhoneCall } from 'lucide-react';

export default function App() {
  const [currentLang, setCurrentLang] = useState<Language>('ar');
  const [activeTab, setActiveTab] = useState<string>('patient');
  const [facilities, setFacilities] = useState<Facility[]>(INITIAL_FACILITIES);
  const [casualties, setCasualties] = useState<MCICasualty[]>(INITIAL_CASUALTIES);
  const [isLoadBalancingApplied, setIsLoadBalancingApplied] = useState<boolean>(false);
  const [selectedDirectionFacility, setSelectedDirectionFacility] = useState<Facility | null>(null);
  const [isJudgeModalOpen, setIsJudgeModalOpen] = useState<boolean>(false);

  // Sync RTL / LTR document direction with language
  useEffect(() => {
    const isRtl = currentLang === 'ar' || currentLang === 'ur';
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = currentLang;
  }, [currentLang]);

  const [backendReady,setBackendReady]=useState(false);
  const [backendError,setBackendError]=useState('');
  const [savedAssessments,setSavedAssessments]=useState(0);
  const [assessments,setAssessments]=useState<any[]>([]);
  const [storageInfo,setStorageInfo]=useState<{storage:string;ok:boolean;connected?:boolean}|null>(null);
  useEffect(()=>{
    const apply=(s:any)=>{setFacilities(s.facilities);setCasualties(s.casualties);setIsLoadBalancingApplied(s.isLoadBalancingApplied);setSavedAssessments(s.assessments.length);setAssessments(s.assessments);setBackendReady(true);setBackendError('');};
    const onState=(e:any)=>apply(e.detail);const onError=(e:any)=>setBackendError(e.detail);
    window.addEventListener('masar-state',onState);window.addEventListener('masar-error',onError);
    loadState().then(apply).catch(reportError);
    getHealth().then(setStorageInfo).catch(()=>{});
    return ()=>{window.removeEventListener('masar-state',onState);window.removeEventListener('masar-error',onError);};
  },[]);
  const send=(body:any)=>{action(body).catch(reportError);};
  const handleUpdateFacilityCapacity=()=>{}; // Server owns atomic reservation and handover updates.
  const handleToggleFacilityStatus=(facilityId:string)=>send({action:'toggleFacility',facilityId});
  const handleToggleCapability=(facilityId:string,capability:string)=>send({action:'toggleCapability',facilityId,capability});
  const handleResetFacilities=()=>send({action:'reset'});
  const handleAddCasualty=(casualty:MCICasualty)=>send({action:'addCasualty',casualty});
  const handleUpdateCasualtyStatus=(casualtyId:string,status:CasualtyStatus)=>send({action:'status',casualtyId,status});
  const handleApplyLoadBalancing=()=>send({action:'balance'});

  const handleSelectJudgeScenario = (scenarioId: string) => {
    if (scenarioId === 'scenario_high_risk' || scenarioId === 'scenario_low_acuity') {
      setActiveTab('patient');
    } else if (scenarioId === 'scenario_mci_thaniya') {
      setActiveTab('mci');
    } else if (scenarioId === 'scenario_command_lab') {
      setActiveTab('command');
      handleApplyLoadBalancing();
    } else if (scenarioId === 'scenario_twin_3d') {
      setActiveTab('twin3d');
    }
  };

  const t = TRANSLATIONS[currentLang];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans w-full max-w-full overflow-x-hidden">
      {/* Header */}
      <Header
        currentLang={currentLang}
        onLanguageChange={setCurrentLang}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenDemoModal={() => setIsJudgeModalOpen(true)}
      />

      <div role="status" className="px-4 py-3 bg-slate-900 border-b border-slate-800 text-sm text-center space-y-1">
        <div className="flex flex-wrap items-center justify-center gap-2 font-medium">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30">
            ● {backendReady ? (storageInfo ? `${storageInfo.storage.toUpperCase()} ${storageInfo.connected ? 'ONLINE' : 'DEGRADED'}` : 'BACKEND CONNECTED') : 'CONNECTING...'}
          </span>
          <span className="text-slate-300">
            {backendReady ? `${savedAssessments} saved assessments · Isolated demo workspace` : 'Connecting to demo backend…'}
          </span>
        </div>
        {backendError && <p role="alert" className="text-red-300 text-xs font-bold">{backendError} — لم يتم حفظ العملية. حدّث الصفحة للمحاولة مجددًا.</p>}
        <p className="text-[11px] text-slate-400 max-w-4xl mx-auto leading-relaxed">
          {currentLang === 'ar'
            ? 'بيانات محاكاة وافتراضية فقط · لا تدخل بيانات مرضى حقيقيين · لا يوجد حذف تلقائي بعد 24 ساعة؛ مسح ملفات تعريف الارتباط بالمتصفح يفقدك الوصول للجلسة (لا تضمن المنصة حفظاً أبدياً).'
            : 'Synthetic demonstration data only · Do not enter real patient data · No automatic 24-hour deletion; clearing browser cookies forfeits workspace access (permanent retention is not guaranteed).'}
        </p>
      </div>
      {/* Main Content Body */}
      <main className="flex-1 pb-16" style={!backendReady?{pointerEvents:"none",opacity:0.5}:undefined}>
        {activeTab === 'patient' && (
          <PatientTriage
            currentLang={currentLang}
            facilities={facilities}
            onOpenDirections={setSelectedDirectionFacility}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'mci' && (
          <ThaniyaMCI
            currentLang={currentLang}
            facilities={facilities}
            casualties={casualties}
            onAddCasualty={handleAddCasualty}
            onUpdateCasualtyStatus={handleUpdateCasualtyStatus}
            onUpdateFacilityCapacity={handleUpdateFacilityCapacity}
          />
        )}

        {activeTab === 'command' && (
          <CommandCenter
            assessments={assessments}
            casualties={casualties}
            currentLang={currentLang}
            facilities={facilities}
            onApplyLoadBalancing={handleApplyLoadBalancing}
            isLoadBalancingApplied={isLoadBalancingApplied}
          />
        )}

        {activeTab === 'twin3d' && (
          <DigitalTwin3D
            currentLang={currentLang}
            facilities={facilities}
            onOpenDirections={setSelectedDirectionFacility}
          />
        )}

        {activeTab === 'lab' && (
          <RoutingLab
            currentLang={currentLang}
            facilities={facilities}
            onToggleFacilityStatus={handleToggleFacilityStatus}
            onToggleCapability={handleToggleCapability}
            onResetFacilities={handleResetFacilities}
          />
        )}

        {activeTab === 'nearby' && (
          <NearbyFacilities
            currentLang={currentLang}
            facilities={facilities}
            onOpenDirections={setSelectedDirectionFacility}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-xs py-8 px-4 text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1.5 text-center md:text-right">
            <div className="flex items-center justify-center md:justify-start gap-2">
              <span className="font-black text-white text-sm">مسار Health | Masar</span>
              <span className="text-teal-400 font-bold">+ ثانية | Thaniya</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-teal-500/10 text-teal-300 border border-teal-500/30">
                MEDATHON 2026
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              فريق FlowCare: Ola Mustafa Alhashim • غيداء عمر الشريف • Alanoud Khalid Albanna • Zayed Mohameed alnefaie
            </p>
          </div>

          <div className="text-center md:text-left text-[11px] text-slate-500 max-w-md">
            {t.prototypeNotice}
          </div>
        </div>
      </footer>

      {/* Judge Demo Walkthrough Modal */}
      <JudgeDemoModal
        isOpen={isJudgeModalOpen}
        onClose={() => setIsJudgeModalOpen(false)}
        onSelectScenario={handleSelectJudgeScenario}
      />

      {/* Directions Modal */}
      <DirectionsModal
        facility={selectedDirectionFacility}
        onClose={() => setSelectedDirectionFacility(null)}
        currentLang={currentLang}
      />
    </div>
  );
}
