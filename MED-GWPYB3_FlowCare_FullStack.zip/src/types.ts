export type Language = 'ar' | 'en' | 'id' | 'ur' | 'fr' | 'tr' | 'bn';

export type AcuityLevel = 'high' | 'urgent' | 'low';

export type FacilityType = 
  | 'emergency_hospital'
  | 'general_hospital'
  | 'primary_center'
  | 'virtual_hub'
  | 'trauma_center';

export interface Facility {
  id: string;
  name: string;
  nameAr: string;
  type: FacilityType;
  zone: string;
  zoneAr: string;
  distanceKm: number;
  travelTimeMinutes: number;
  totalBeds: number;
  occupiedBeds: number;
  reservedBeds: number; // Reserved by ambulances en-route
  capabilities: string[];
  isOperational: boolean;
  erAccepting: boolean;
  lastUpdatedMinutesAgo: number;
  contactNumber: string;
  lat: number;
  lng: number;
}

export type TriageTag = 'red' | 'yellow' | 'green' | 'black';

export type CasualtyStatus = 'field_triage' | 'assigned' | 'en_route' | 'delivered';

export interface MCICasualty {
  id: string;
  incidentId: string;
  tag: TriageTag;
  ageGroup: 'adult' | 'child' | 'elderly' | 'unknown';
  gender: 'male' | 'female' | 'unknown';
  injuryDescription: string;
  injuryDescriptionAr: string;
  respiratoryRate?: number;
  radialPulsePresent: boolean;
  mentalStatus: 'can_follow_commands' | 'cannot_follow' | 'unresponsive';
  requiredCapability: string;
  assignedFacilityId?: string;
  assignedAmbulanceId?: string;
  status: CasualtyStatus;
  reportedAt: string;
  enRouteAt?: string;
  deliveredAt?: string;
}

export interface PatientTriageInput {
  ageGroup: 'infant' | 'child' | 'adult' | 'elderly';
  gender: 'male' | 'female';
  zone: string;
  mainSymptom: string;
  severity: number;
  redFlags: {
    difficultyBreathingSevere: boolean | 'unsure';
    chestPainSevere: boolean | 'unsure';
    lossOfConsciousness: boolean | 'unsure';
    severeBleeding: boolean | 'unsure';
    suddenConfusion: boolean | 'unsure';
    unableToWalkOrDrink: boolean | 'unsure';
  };
  chronicConditions?: string[];
}

export interface TriageEvaluation {
  acuity: AcuityLevel;
  acuityScore: number;
  reasons: string[];
  reasonsAr: string[];
  isRedFlagTriggered: boolean;
  recommendedFacility: Facility;
  alternativeFacility?: Facility;
  virtualOptionAvailable: boolean;
  decisionExplanation: {
    ruleApplied: string;
    ruleAppliedAr: string;
    whyChosen: string;
    whyChosenAr: string;
    whyOthersExcluded: { facilityId: string; reason: string; reasonAr: string }[];
  };
}

export interface SurgePrediction {
  facilityId: string;
  predictedSurgePercent: number;
  timeframeMinutes: number;
  confidencePercent: number;
  cause: string;
  causeAr: string;
  recommendedIntervention: string;
  recommendedInterventionAr: string;
}
