import React from 'react';
import { 
  PlayCircle, 
  X, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldAlert, 
  Radio, 
  ArrowRight,
  Sparkles,
  Users,
  Compass
} from 'lucide-react';
import { Language } from '../types';

interface JudgeDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectScenario: (scenarioId: string) => void;
}

export const JudgeDemoModal: React.FC<JudgeDemoModalProps> = ({
  isOpen,
  onClose,
  onSelectScenario
}) => {
  if (!isOpen) return null;

  const scenarios = [
    {
      id: 'scenario_high_risk',
      title: 'سيناريو 1: مريض حرج (أحمد - 68 عاماً - ألم صدري حاد)',
      badge: 'High Risk 🔴',
      badgeColor: 'bg-red-500/20 text-red-300 border-red-500/40',
      description: 'حاج يشعر بألم صدري ضاغط وضيق تنفس أثناء الطواف. يكتشف النظام علامات الخطر (Red Flags)، ويصنف الحالة كأولوية قصوى، ويوجهه فوراً لطوارئ الحرم (ألفا) متجاوزاً نسبة إشغالها المرتفعة (92%) لأن الأمان السريري يتغلب على الازدحام.',
      stepToRun: 'تشغيل الفرز وإظهار التوجيه الإسعافي'
    },
    {
      id: 'scenario_low_acuity',
      title: 'سيناريو 2: مريض منخفض الخطورة (فاطمة - 29 عاماً - التهاب حلق)',
      badge: 'Low Acuity 🟢',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
      description: 'حاجة تعاني من التهاب حلق خفيف وصداع بدون علامات خطر. النظام يستبعد طوارئ المستشفيات المزدحمة تلقائياً ويوجهها لمركز دلتا الأولي أو مستشفى صحة الافتراضي، لتوفير أسرّة الطوارئ للحالات الحرجة.',
      stepToRun: 'تشغيل الفرز وإظهار تحويل الرعاية الأولية'
    },
    {
      id: 'scenario_mci_thaniya',
      title: 'سيناريو 3: حادث تدافع وإدارة الإصابات الجماعية (ثانية)',
      badge: 'MCI Dispatch 🚨',
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
      description: 'حادث تدافع في مشعر منى. يتم تصنيف 5 مصابين (أحمر، أصفر، أخضر)، وحجز السعة السريرية لسيارة الإسعاف قيد النقل، ثم تأكيد الاستلام في المستشفى دون أي ازدواجية في عدّ الأسرّة.',
      stepToRun: 'فتح نظام ثانية ومحاكاة النقل والحجز'
    },
    {
      id: 'scenario_command_lab',
      title: 'سيناريو 4: مركز القيادة والتنبؤ بالازدحام ومختبر التوجيه',
      badge: 'AI Surge & Lab 📊',
      badgeColor: 'bg-teal-500/20 text-teal-300 border-teal-500/40',
      description: 'التنبؤ بزيادة الضغط بنسبة 28% على طوارئ ألفا خلال 45 دقيقة عقب صلاة الظهر، مع تطبيق التوجيه التنبؤي المتوازن ومقارنة 20 حالة قبل وبعد التوجيه.',
      stepToRun: 'فتح مركز القيادة وتفعيل موازنة الحمل'
    },
    {
      id: 'scenario_twin_3d',
      title: 'سيناريو 5: التوأم الرقمي ثلاثي الأبعاد (3D Digital Twin) للمشاعر المقدسة',
      badge: '3D Simulation 🕋',
      badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
      description: 'محاكاة ثلاثية الأبعاد تفاعلية بالكعبة المشرفة وساحات الحرم، خيام منى، منشأة الجمرات، ومستشفيات الطوارئ مع تتبع سيارات الإسعاف ومسارات التدفق الحية.',
      stepToRun: 'تشغيل التوأم الرقمي ثلاثي الأبعاد'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto relative">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <PlayCircle className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white">
                سيناريوهات العرض التفاعلي للجنة التحكيم (MEDATHON Demo)
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                اختر أي سيناريو لاختبار المحرك الذكي في ثوانٍ معدودة
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          {scenarios.map((sc) => (
            <div
              key={sc.id}
              className="p-5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-teal-500/50 transition-all space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <span>{sc.title}</span>
                </h3>
                <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold border shrink-0 ${sc.badgeColor}`}>
                  {sc.badge}
                </span>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                {sc.description}
              </p>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => {
                    onSelectScenario(sc.id);
                    onClose();
                  }}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-md shadow-teal-600/20 transition-all"
                >
                  <span>{sc.stepToRun}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
