import React, { useState } from 'react';
import { 
  Radio, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowUpRight, 
  Activity, 
  Zap, 
  ShieldCheck, 
  Clock, 
  Sparkles,
  Users,
  Flame,
  ArrowRight
} from 'lucide-react';
import { Facility, Language, SurgePrediction } from '../types';
import { INITIAL_PREDICTIONS } from '../data/mockData';

interface CommandCenterProps {
  currentLang: Language;
  assessments: {acuity:string}[];
  casualties: {tag:string;status:string}[];
  facilities: Facility[];
  onApplyLoadBalancing: () => void;
  isLoadBalancingApplied: boolean;
}

export const CommandCenter: React.FC<CommandCenterProps> = ({
  facilities,
  assessments,
  casualties,
  onApplyLoadBalancing,
  isLoadBalancingApplied
}) => {
  const [predictions, setPredictions] = useState<SurgePrediction[]>(INITIAL_PREDICTIONS);

  // Simulated metrics
  const totalActivePatients = assessments.length + casualties.filter(c=>c.status!=="delivered" && c.tag!=="black").length;
  const highAcuityCount = assessments.filter(a=>a.acuity==="high").length + casualties.filter(c=>c.tag==="red"&&c.status!=="delivered").length;
  const urgentAcuityCount = assessments.filter(a=>a.acuity==="urgent").length + casualties.filter(c=>c.tag==="yellow"&&c.status!=="delivered").length;
  const lowAcuityCount = assessments.filter(a=>a.acuity==="low").length + casualties.filter(c=>c.tag==="green"&&c.status!=="delivered").length;

  const divertedCases = isLoadBalancingApplied ? 538 : 412;
  const edHoursSaved = isLoadBalancingApplied ? 620 : 485;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Command Center Title & Alert Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950/60 to-slate-900 p-6 sm:p-8 rounded-3xl border border-teal-500/40 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/40 text-xs font-bold mb-2">
              <Radio className="w-3.5 h-3.5 text-teal-400 animate-pulse" />
              <span>SIMULATED DEMO WORKSPACE · BACKEND CONNECTED</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              مركز قيادة الحشود وإدارة التدفق الصحي
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              لوحة تحكم مركزية للجهات الصحية (وزارة الصحة والهلال الأحمر) تعرض حالات التجربة المحفوظة، وتعرض سيناريو ازدحام افتراضي قبل حدوثه بـ 30-60 دقيقة، وتوازن التدفق بين المستشفيات والمراكز الأولية.
            </p>
          </div>

          {/* Load Balancing Action Button */}
          <div className="shrink-0 w-full sm:w-auto">
            <button
              onClick={onApplyLoadBalancing}
              className={`w-full sm:w-auto px-5 py-3.5 rounded-2xl font-black text-xs flex items-center justify-center gap-2.5 transition-all shadow-xl ${
                isLoadBalancingApplied
                  ? 'bg-emerald-600 text-white shadow-emerald-600/30 ring-2 ring-emerald-400/50'
                  : 'bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-400 hover:to-cyan-400 text-white shadow-teal-500/30'
              }`}
            >
              <Zap className="w-4 h-4 text-amber-300" />
              <span>
                {isLoadBalancingApplied 
                  ? 'تم تفعيل التوجيه التنبؤي المتوازن ✓' 
                  : 'تطبيق التوجيه التنبؤي التلقائي (Load Balancing)'}
              </span>
            </button>
            <div className="text-[10px] text-center text-slate-400 mt-1.5 font-medium">
              {isLoadBalancingApplied ? 'يعمل النظام حالياً على تحويل الحالات البسيطة إلى المراكز البديلة' : 'اضغط لتفريغ 35 سرير طوارئ مسبقاً'}
            </div>
          </div>
        </div>
      </div>

      {/* KPI Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Demand */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
            <span>إجمالي طلبات التوجيه</span>
            <Users className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white">{totalActivePatients.toLocaleString()}</div>
          <div className="text-[11px] text-teal-400 flex items-center gap-1">
            <ArrowUpRight className="w-3 h-3" />
            <span>+14% مقارنة بالساعة السابقة</span>
          </div>
        </div>

        {/* Acuity Distribution */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="text-slate-400 text-xs font-semibold flex items-center justify-between">
            <span>توزيع درجات الخطورة</span>
            <Activity className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-xs font-bold text-red-400">🔴 {highAcuityCount}</span>
            <span className="text-xs font-bold text-amber-400">🟠 {urgentAcuityCount}</span>
            <span className="text-xs font-bold text-emerald-400">🟢 {lowAcuityCount}</span>
          </div>
          {/* Stacked bar */}
          <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden flex">
            <div style={{ width: `${totalActivePatients > 0 ? (highAcuityCount / totalActivePatients) * 100 : 0}%` }} className="bg-red-500 h-full" />
            <div style={{ width: `${totalActivePatients > 0 ? (urgentAcuityCount / totalActivePatients) * 100 : 0}%` }} className="bg-amber-400 h-full" />
            <div style={{ width: `${totalActivePatients > 0 ? (lowAcuityCount / totalActivePatients) * 100 : 0}%` }} className="bg-emerald-400 h-full" />
          </div>
          <div className="text-[10px] text-slate-400">
            {totalActivePatients > 0 
              ? `${Math.round((lowAcuityCount / totalActivePatients) * 100)}% من الحالات منخفضة الخطورة`
              : 'لا توجد حالات نشطة حالياً'}
          </div>
        </div>

        {/* Diverted Cases */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
            <span>حالات حُوِّلت بعيداً عن الطوارئ</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-400">{divertedCases}</div>
          <div className="text-[11px] text-slate-300">
            توفير <strong className="text-white">34%</strong> من سعة أسرّة الطوارئ
          </div>
        </div>

        {/* Wait Time Saved */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
            <span>ساعات انتظار تم توفيرها</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-cyan-400">{edHoursSaved} ساعة</div>
          <div className="text-[11px] text-slate-400">
            بمعدل 48 دقيقة لكل مريض تم توجيهه
          </div>
        </div>
      </div>

      {/* Predictive Surge Forecast & AI Alerts */}
      <div className="bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-950 p-6 rounded-3xl border border-amber-500/40 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-amber-800/40 pb-4">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-amber-400 animate-spin" />
            <h3 className="text-base font-bold text-white">
              توقعات الذكاء الاصطناعي للازدحام الصحي (Predictive AI Surge Alerts)
            </h3>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
            أفق التنبؤ: 30 - 60 دقيقة قادمة
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {predictions.map((p, idx) => {
            const fac = facilities.find(f => f.id === p.facilityId);
            return (
              <div 
                key={idx}
                className="p-5 rounded-2xl bg-slate-950/90 border border-amber-500/30 space-y-3 relative overflow-hidden"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider block">
                      ⚠️ توقع ضغط متزايد ({p.timeframeMinutes} دقيقة)
                    </span>
                    <h4 className="text-sm font-bold text-white mt-0.5">
                      {fac?.nameAr}
                    </h4>
                  </div>
                  <span className="text-xs font-mono font-black px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    +{p.predictedSurgePercent}%
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  <strong>السبب المحتمل:</strong> {p.causeAr}
                </p>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-teal-300">
                  <strong>الإجراء الموصى به:</strong> {p.recommendedInterventionAr}
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 font-mono">
                  <span>درجة الثقة: {p.confidencePercent}%</span>
                  <span>خوارزمية التدفق: Poisson Crowd Arrival Model</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Facilities Real-Time Utilization Grid */}
      <div className="bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-teal-400" />
              <span>معدل إشغال المنشآت الصحية في الوقت الفعلي</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              يعكس أثر إعادة التوجيه الذكي ومقارنة السعة الحالية بالسعة المستهدفة
            </p>
          </div>
          <span className="text-xs text-slate-400">
            تحديث تجريبي • 6 منشآت صحية بالمحاكاة
          </span>
        </div>

        <div className="space-y-4">
          {facilities.map((fac) => {
            const totalLoad = fac.occupiedBeds + fac.reservedBeds;
            const occupancyPct = Math.min(100, Math.round((totalLoad / fac.totalBeds) * 100));
            const isHigh = occupancyPct >= 85;
            const isMedium = occupancyPct >= 60 && occupancyPct < 85;

            return (
              <div 
                key={fac.id}
                className="p-4 rounded-2xl bg-slate-950 border border-slate-800/90 space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <span className={`w-3 h-3 rounded-full ${isHigh ? 'bg-red-500 animate-ping' : isMedium ? 'bg-amber-400' : 'bg-emerald-400'}`} />
                    <div>
                      <h4 className="text-sm font-bold text-white">{fac.nameAr}</h4>
                      <span className="text-xs text-slate-400">{fac.zoneAr} ({fac.travelTimeMinutes} دقيقة وصول)</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-xs font-mono">
                    <span className="text-slate-400">
                      الأسرّة: <strong className="text-white">{totalLoad}</strong> / {fac.totalBeds}
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full font-bold ${
                      isHigh ? 'bg-red-500/20 text-red-300 border border-red-500/40' : isMedium ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'
                    }`}>
                      {occupancyPct}%
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden flex">
                  <div 
                    style={{ width: `${(fac.occupiedBeds / fac.totalBeds) * 100}%` }}
                    className={`h-full ${isHigh ? 'bg-red-500' : isMedium ? 'bg-amber-500' : 'bg-emerald-500'}`}
                  />
                  <div 
                    style={{ width: `${(fac.reservedBeds / fac.totalBeds) * 100}%` }}
                    className="bg-amber-400 h-full animate-pulse"
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
