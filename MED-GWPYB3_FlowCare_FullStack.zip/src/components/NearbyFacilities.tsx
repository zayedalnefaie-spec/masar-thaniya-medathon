import React, { useState } from 'react';
import { 
  MapPin, 
  Navigation, 
  ExternalLink, 
  Building2, 
  PhoneCall, 
  Clock, 
  ShieldAlert, 
  Video, 
  Search,
  Filter,
  CheckCircle2,
  Compass
} from 'lucide-react';
import { Facility, Language } from '../types';
import { ZONES } from '../data/mockData';

interface NearbyFacilitiesProps {
  currentLang: Language;
  facilities: Facility[];
  onOpenDirections: (facility: Facility) => void;
}

export const NearbyFacilities: React.FC<NearbyFacilitiesProps> = ({
  facilities,
  onOpenDirections
}) => {
  const [selectedZone, setSelectedZone] = useState<string>('haram_plaza');
  const [filterType, setFilterType] = useState<string>('all');
  const [userGpsActive, setUserGpsActive] = useState<boolean>(false);
  const [gpsError, setGpsError] = useState<string | null>(null);

  const handleRequestGps = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        () => {
          setUserGpsActive(true);
          setGpsError(null);
        },
        () => {
          setGpsError('تعذر تحديد موقع GPS تلقائياً، يمكنك الاختيار يدوياً من قائمة المشاعر');
          setUserGpsActive(false);
        }
      );
    } else {
      setGpsError('المتصفح لا يدعم تحديد الموقع الجغرافي');
    }
  };

  const filteredFacilities = facilities.filter(f => {
    if (filterType === 'all') return true;
    if (filterType === 'er') return f.capabilities.includes('er');
    if (filterType === 'primary') return f.type === 'primary_center';
    if (filterType === 'virtual') return f.type === 'virtual_hub';
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Header & GPS Locator */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950/40 to-slate-900 p-6 sm:p-8 rounded-3xl border border-teal-500/40 shadow-2xl space-y-4">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/40 text-xs font-bold mb-2">
              <Compass className="w-4 h-4 text-teal-400 animate-spin" />
              <span>NEARBY HEALTHCARE FACILITIES & GPS NAVIGATION</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              المنشآت الصحية القريبة والموقع الجغرافي
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
              استكشف المستشفيات ومراكز الرعاية الأولية ومحطات الإرواء الأقرب إليك مع توضيح المسافة وزمن الوصول والإشغال.
            </p>
          </div>

          <button
            onClick={handleRequestGps}
            className={`px-5 py-3 rounded-2xl font-bold text-xs flex items-center gap-2 border transition-all ${
              userGpsActive
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 ring-2 ring-emerald-500/20'
                : 'bg-slate-800 hover:bg-slate-700 text-teal-300 border-teal-500/30'
            }`}
          >
            <Navigation className="w-4 h-4 text-teal-400" />
            <span>{userGpsActive ? 'الموقع الجغرافي نشط ✓' : 'استخدم موقعي الحالي (GPS)'}</span>
          </button>
        </div>

        {gpsError && (
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs">
            {gpsError}
          </div>
        )}

        {/* Zone Selector Pills */}
        <div className="pt-2">
          <span className="text-[11px] font-bold text-slate-400 block mb-2">اختر موقعك الميداني يدوياً:</span>
          <div className="flex flex-wrap gap-2">
            {ZONES.map((z) => (
              <button
                key={z.id}
                onClick={() => setSelectedZone(z.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  selectedZone === z.id
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/60 font-bold'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                {z.nameAr}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Interactive Map Visualizer */}
      <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-teal-400" />
            <h3 className="text-base font-bold text-white">
              خريطة المشاعر المقدسة والمنشآت الصحية
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            خريطة تخطيطية تفاعلية للمشاعر
          </span>
        </div>

        {/* Stylized SVG Map */}
        <div className="w-full h-72 bg-slate-950 rounded-2xl border border-slate-800 relative overflow-hidden flex items-center justify-center p-4">
          <svg className="w-full h-full text-slate-700" viewBox="0 0 800 350">
            {/* Holy Sites Connecting Pathways */}
            <path d="M 120 180 Q 250 80 400 160 T 680 180" fill="none" stroke="#1e293b" strokeWidth="6" strokeDasharray="6 6" />
            <path d="M 400 160 L 520 280 L 680 180" fill="none" stroke="#1e293b" strokeWidth="4" />

            {/* Zone Areas */}
            <circle cx="140" cy="180" r="45" fill="#0f766e" fillOpacity="0.15" stroke="#14b8a6" strokeWidth="1.5" />
            <text x="140" y="185" textAnchor="middle" fill="#5eead4" fontSize="12" fontWeight="bold">الحرم المكي</text>

            <circle cx="400" cy="150" r="50" fill="#0369a1" fillOpacity="0.15" stroke="#0ea5e9" strokeWidth="1.5" />
            <text x="400" y="155" textAnchor="middle" fill="#7dd3fc" fontSize="12" fontWeight="bold">مشعر منى والجمرات</text>

            <circle cx="530" cy="280" r="40" fill="#047857" fillOpacity="0.15" stroke="#10b981" strokeWidth="1.5" />
            <text x="530" y="285" textAnchor="middle" fill="#6ee7b7" fontSize="12" fontWeight="bold">مزدلفة</text>

            <circle cx="680" cy="180" r="45" fill="#b45309" fillOpacity="0.15" stroke="#f59e0b" strokeWidth="1.5" />
            <text x="680" y="185" textAnchor="middle" fill="#fcd34d" fontSize="12" fontWeight="bold">صعيد عرفات</text>

            {/* Hospital Pins */}
            {facilities.filter(f => f.type !== 'virtual_hub').map((f, i) => {
              const xPos = 140 + (i * 110);
              const yPos = 100 + ((i % 2) * 110);
              return (
                <g key={f.id} className="cursor-pointer" onClick={() => onOpenDirections(f)}>
                  <circle cx={xPos} cy={yPos} r="14" fill="#0f172a" stroke="#14b8a6" strokeWidth="2" />
                  <circle cx={xPos} cy={yPos} r="6" fill={f.occupiedBeds / f.totalBeds > 0.85 ? '#ef4444' : '#10b981'} className="animate-pulse" />
                  <text x={xPos} y={yPos - 20} textAnchor="middle" fill="#f8fafc" fontSize="11" fontWeight="bold">
                    {f.nameAr.split(' ')[0]} {f.nameAr.split(' ')[1]}
                  </text>
                  <text x={xPos} y={yPos + 26} textAnchor="middle" fill="#94a3b8" fontSize="9">
                    {f.travelTimeMinutes} دقيقة • {Math.round((f.occupiedBeds / f.totalBeds) * 100)}%
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      </div>

      {/* Facilities Cards Grid with Filters */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-teal-400" />
            <h3 className="text-base font-bold text-white">قائمة المنشآت والخدمات الصحية</h3>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {[
              { id: 'all', label: 'الكل' },
              { id: 'er', label: 'أقسام الطوارئ (ER)' },
              { id: 'primary', label: 'مراكز رعاية أولية' },
              { id: 'virtual', label: 'صحة الافتراضي' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilterType(f.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                  filterType === f.id
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/60 font-bold'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredFacilities.map((fac) => {
            const loadPct = Math.round((fac.occupiedBeds / fac.totalBeds) * 100);
            return (
              <div 
                key={fac.id}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="text-sm font-bold text-white">{fac.nameAr}</h4>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      loadPct > 85 ? 'bg-red-500/20 text-red-300' : 'bg-emerald-500/20 text-emerald-300'
                    }`}>
                      {loadPct}% إشغال
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-teal-400" />
                    <span>{fac.zoneAr}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-300 pt-3 border-t border-slate-800">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-teal-400" />
                    <span>{fac.travelTimeMinutes} دقيقة ({fac.distanceKm} كم)</span>
                  </span>
                  <button
                    onClick={() => onOpenDirections(fac)}
                    className="px-3.5 py-1.5 rounded-xl bg-teal-500/10 hover:bg-teal-500/20 text-teal-300 border border-teal-500/30 text-xs font-bold transition-all flex items-center gap-1"
                  >
                    <ExternalLink className="w-3 h-3" />
                    <span>الاتجاهات</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
