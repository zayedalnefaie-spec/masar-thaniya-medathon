import React, { useState } from 'react';
import { 
  Activity, 
  Globe, 
  ShieldAlert, 
  PhoneCall, 
  Sparkles, 
  Radio, 
  Layers, 
  Sliders, 
  MapPin, 
  PlayCircle,
  Menu,
  X,
  Boxes
} from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface HeaderProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onOpenDemoModal: () => void;
}

const LANGUAGES: { code: Language; label: string; flag: string }[] = [
  { code: 'ar', label: 'العربية', flag: '🇸🇦' },
  { code: 'en', label: 'English', flag: '🇬🇧' },
  { code: 'id', label: 'Bahasa Indonesia', flag: '🇮🇩' },
  { code: 'ur', label: 'اردو', flag: '🇵🇰' },
  { code: 'fr', label: 'Français', flag: '🇫🇷' },
  { code: 'tr', label: 'Türkçe', flag: '🇹🇷' },
  { code: 'bn', label: 'বাংলা', flag: '🇧🇩' },
];

export const Header: React.FC<HeaderProps> = ({
  currentLang,
  onLanguageChange,
  activeTab,
  onTabChange,
  onOpenDemoModal
}) => {
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = TRANSLATIONS[currentLang];
  const isRtl = currentLang === 'ar' || currentLang === 'ur';

  const navItems = [
    { id: 'patient', label: t.navPatient, icon: Activity },
    { id: 'mci', label: t.navMCI, icon: ShieldAlert, badge: 'MCI 🚨' },
    { id: 'command', label: t.navCommand, icon: Radio, badge: 'SIMULATED' },
    { id: 'twin3d', label: t.navTwin3D, icon: Boxes, badge: '3D 🕋' },
    { id: 'lab', label: t.navLab, icon: Sliders },
    { id: 'nearby', label: t.navNearby, icon: MapPin },
  ];

  return (
    <header className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-slate-100 shadow-xl w-full max-w-full overflow-hidden">
      {/* Top Emergency & Prototype Banner */}
      <div className="bg-gradient-to-r from-teal-950 via-slate-900 to-emerald-950 text-[11px] sm:text-xs px-3 sm:px-4 py-1.5 border-b border-teal-800/40 flex flex-wrap items-center justify-between gap-1.5 sm:gap-2">
        <div className="flex items-center gap-1.5 sm:gap-2 text-teal-300 font-medium min-w-0">
          <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
          <span className="truncate">{t.prototypeNotice}</span>
        </div>
        <div className="flex items-center gap-2 sm:gap-4 text-slate-300 shrink-0">
          <span className="hidden md:inline text-slate-400">{t.emergencyHotlineNote}:</span>
          <a
            href="tel:997"
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 border border-red-500/40 font-bold hover:bg-red-500/30 transition-colors"
          >
            <PhoneCall className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-red-400 animate-pulse" />
            <span>{t.call997}</span>
          </a>
          <span className="text-slate-600">|</span>
          <a
            href="tel:937"
            className="text-teal-400 hover:text-teal-300 font-semibold text-[11px] sm:text-xs"
          >
            صحة (937)
          </a>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between min-h-[4rem] py-2 gap-2 min-w-0">
          
          {/* Logo & Brand */}
          <div 
            onClick={() => onTabChange('patient')}
            className="flex items-center gap-2 sm:gap-3 cursor-pointer group min-w-0 shrink"
          >
            <div className="relative flex items-center justify-center w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-tr from-teal-600 via-emerald-600 to-cyan-500 shadow-lg shadow-teal-500/20 group-hover:scale-105 transition-transform shrink-0">
              <Activity className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              <div className="absolute -top-1 -right-1 w-3 h-3 sm:w-3.5 sm:h-3.5 bg-red-500 rounded-full border-2 border-slate-900" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <span className="text-sm sm:text-lg font-black tracking-tight text-white flex items-center gap-1">
                  مسار <span className="text-teal-400 font-light">Health</span>
                </span>
                <span className="text-[10px] sm:text-xs px-1.5 sm:px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold whitespace-nowrap">
                  + ثانية
                </span>
              </div>
              <p className="text-[10px] sm:text-xs text-slate-400 font-medium truncate max-w-[120px] sm:max-w-xs">
                {t.slogan}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-950/60 p-1.5 rounded-2xl border border-slate-800">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onTabChange(item.id)}
                  className={`relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-md shadow-teal-600/30'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                      isActive 
                        ? 'bg-white/20 text-white' 
                        : item.badge.includes('MCI') 
                          ? 'bg-red-500/20 text-red-300 border border-red-500/40' 
                          : 'bg-teal-500/20 text-teal-300'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Controls: Judge Demo + Language Selector + Mobile Menu */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
            {/* Quick Judge Demo Trigger */}
            <button
              onClick={onOpenDemoModal}
              className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1.5 sm:py-2 rounded-xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 text-[11px] sm:text-xs font-bold transition-all shadow-sm group"
              title="عرض سيناريوهات الهاكاثون للجنة التحكيم"
            >
              <PlayCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400 group-hover:scale-110 transition-transform shrink-0" />
              <span className="hidden sm:inline">{t.navJudgeDemo}</span>
              <span className="sm:hidden font-mono text-[10px]">Demo</span>
            </button>

            {/* Language Selector Dropdown */}
            <div className="relative">
              <button
                onClick={() => setLangMenuOpen(!langMenuOpen)}
                className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1.5 sm:py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] sm:text-xs font-semibold border border-slate-700 transition-colors"
                aria-label={t.chooseLanguage}
              >
                <Globe className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-teal-400 shrink-0" />
                <span className="font-medium hidden sm:inline">
                  {LANGUAGES.find(l => l.code === currentLang)?.flag} {LANGUAGES.find(l => l.code === currentLang)?.label}
                </span>
                <span className="font-medium sm:hidden">
                  {LANGUAGES.find(l => l.code === currentLang)?.flag}
                </span>
              </button>

              {langMenuOpen && (
                <div 
                  className={`absolute mt-2 w-48 rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl py-1 z-50 ${
                    isRtl ? 'left-0' : 'right-0'
                  }`}
                >
                  <div className="px-3 py-2 text-[11px] font-semibold text-slate-400 border-b border-slate-800">
                    {t.chooseLanguage}
                  </div>
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        onLanguageChange(lang.code);
                        setLangMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium text-right hover:bg-slate-800 transition-colors ${
                        currentLang === lang.code ? 'bg-teal-500/10 text-teal-400 font-bold' : 'text-slate-300'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span>{lang.flag}</span>
                        <span>{lang.label}</span>
                      </span>
                      {currentLang === lang.code && (
                        <span className="w-1.5 h-1.5 rounded-full bg-teal-400" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-1.5 sm:p-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
              aria-label="القائمة"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Nav */}
        {mobileMenuOpen && (
          <div className="lg:hidden py-3 border-t border-slate-800 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onTabChange(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-xs font-semibold ${
                    isActive
                      ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/20 font-bold">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </header>
  );
};
