import React, { useState } from 'react';
import { 
  Sliders, 
  ArrowRightLeft, 
  Power, 
  Building2, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  ShieldAlert, 
  RefreshCcw, 
  Info,
  TrendingDown,
  Clock,
  Sparkles
} from 'lucide-react';
import { Facility, Language } from '../types';

interface RoutingLabProps {
  currentLang: Language;
  facilities: Facility[];
  onToggleFacilityStatus: (facilityId: string) => void;
  onToggleCapability: (facilityId: string, capability: string) => void;
  onResetFacilities: () => void;
}

interface SimulatedPatientCase {
  id: number;
  descriptionAr: string;
  acuity: 'high' | 'urgent' | 'low';
  requiredCapability: string;
  traditionalChoice: string; // "Without Masar" (always nearest hospital)
  masarChoice: string; // "With Masar" (MIRE safety & load-balanced)
  reasonAr: string;
}

const SAMPLE_20_CASES: SimulatedPatientCase[] = [
  { id: 1, descriptionAr: 'ألم صدري حاد وتعرق بارد (اشتباه جلطة)', acuity: 'high', requiredCapability: 'er', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'طوارئ ألفا (4 د)', reasonAr: 'حالة حرجة: أولوية الأمان السريري تلغي الازدحام' },
  { id: 2, descriptionAr: 'التهاب حلق بسيط ورشح خفيف', acuity: 'low', requiredCapability: 'primary_care', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مركز صحي دلتا (9 د)', reasonAr: 'حالة بسيطة: تحويل لتفادي انتظار 3 ساعات وتفريغ سرير الطوارئ' },
  { id: 3, descriptionAr: 'اشتباه كسر ساق بعد تعثر وسقوط', acuity: 'urgent', requiredCapability: 'urgent_care', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مستشفى بيتا (11 د)', reasonAr: 'حالة عاجلة: مستشفى بيتا أقل ازدحاماً ومجهز بجبائر وأشعة' },
  { id: 4, descriptionAr: 'صداع خفيف بعد المشي الطويل', acuity: 'low', requiredCapability: 'primary_care', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مستشفى صحة الافتراضي (فوري)', reasonAr: 'استشارة افتراضية فورية دون الحاجة للذهاب للمستشفى' },
  { id: 5, descriptionAr: 'نزيف شرياني حاد باليد', acuity: 'high', requiredCapability: 'er', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'طوارئ ألفا (4 د)', reasonAr: 'حالة حرجة: إلزامية التوجه لأقرب طوارئ مجهزة' },
  { id: 6, descriptionAr: 'إجهاد حراري ودوخة خفيفة', acuity: 'urgent', requiredCapability: 'heat_exhaustion', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مركز صحي جاما (7 د)', reasonAr: 'مركز جاما مجهز بغرفة إرواء ورذاذ تبريد متخصصة' },
  { id: 7, descriptionAr: 'طفح جلدي بسيط وحكة', acuity: 'low', requiredCapability: 'primary_care', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مركز صحي دلتا (9 د)', reasonAr: 'رعاية أولية تكفي للعلاج وتمنع التزاحم غير المبرر' },
  { id: 8, descriptionAr: 'ضيق تنفس حاد وازرقاق الشفاه', acuity: 'high', requiredCapability: 'er', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'طوارئ ألفا (4 د)', reasonAr: 'حالة حرجة مهددة للحياة فوراً' },
  { id: 9, descriptionAr: 'سعال جاف مستمر منذ يومين', acuity: 'low', requiredCapability: 'primary_care', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مستشفى صحة الافتراضي (فوري)', reasonAr: 'وصفة دوائية إلكترونية عبر تطبيق صحتي' },
  { id: 10, descriptionAr: 'ألم بالبطن مع إسهال متكرر', acuity: 'urgent', requiredCapability: 'urgent_care', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مركز صحي جاما (7 د)', reasonAr: 'فحص عاجل وإعطاء محاليل وريدية بدون إشغال الطوارئ' },
  { id: 11, descriptionAr: 'حروق عميقة بالوجه واليدين', acuity: 'high', requiredCapability: 'burn_unit', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مستشفى النور التخصصي (16 د)', reasonAr: 'تطابق تخصصي: ألفا تفتقر لوحدة حروق تخصصية عليا' },
  { id: 12, descriptionAr: 'فقدان وعي وتشنج حاد', acuity: 'high', requiredCapability: 'er', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'طوارئ ألفا (4 د)', reasonAr: 'حالة حرجة: توجيه لأقرب إنعاش قلبي ورئوي' },
  { id: 13, descriptionAr: 'جرح سطحي في الإبهام', acuity: 'low', requiredCapability: 'minor_trauma', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مركز صحي دلتا (9 د)', reasonAr: 'ضماد وخياطة بسيطة في المركز الأولي' },
  { id: 14, descriptionAr: 'حمى 39.5 م مع رجفة', acuity: 'urgent', requiredCapability: 'urgent_care', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مستشفى بيتا (11 د)', reasonAr: 'متابعة وفحص دم وتخفيض حرارة في بيئة مستقرة' },
  { id: 15, descriptionAr: 'التهاب عيني خفيف واحمرار', acuity: 'low', requiredCapability: 'primary_care', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مركز صحي دلتا (9 د)', reasonAr: 'قطرات معقمة واستشارة طبيب عام' },
  { id: 16, descriptionAr: 'اشتباه نزيف داخلي إثر دهس', acuity: 'high', requiredCapability: 'trauma', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'طوارئ ألفا (4 د)', reasonAr: 'تدخل جراحي إسعافي عاجل' },
  { id: 17, descriptionAr: 'ألم مفصل الركبة بعد السعي', acuity: 'low', requiredCapability: 'primary_care', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مركز صحي دلتا (9 د)', reasonAr: 'مسكنات وراحة دون تكبد عناء الطوارئ' },
  { id: 18, descriptionAr: 'هبوط سكر الدم ودوخة', acuity: 'urgent', requiredCapability: 'urgent_care', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مركز صحي جاما (7 د)', reasonAr: 'إعطاء جلوكوز وتعديل جرعة الإنسولين' },
  { id: 19, descriptionAr: 'صعوبة بالبلع وبحة صوت', acuity: 'low', requiredCapability: 'primary_care', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'مستشفى صحة الافتراضي (فوري)', reasonAr: 'استشارة طبيب افتراضي متعدد اللغات' },
  { id: 20, descriptionAr: 'ضربة شمس وغيبوبة حرارية', acuity: 'high', requiredCapability: 'er', traditionalChoice: 'طوارئ ألفا (4 د)', masarChoice: 'طوارئ ألفا (4 د)', reasonAr: 'إنعاش وغمر بالماء البارد فوراً' }
];

export const RoutingLab: React.FC<RoutingLabProps> = ({
  facilities,
  onToggleFacilityStatus,
  onResetFacilities
}) => {
  const [filterAcuity, setFilterAcuity] = useState<string>('all');

  const filteredCases = SAMPLE_20_CASES.filter(c => {
    if (filterAcuity === 'all') return true;
    return c.acuity === filterAcuity;
  });

  // Calculate stats
  const casesSentToAlfaTraditional = 18; // 90% go to nearest
  const casesSentToAlfaMasar = 7; // Only the 7 critical ones!
  const reductionPercent = Math.round(((casesSentToAlfaTraditional - casesSentToAlfaMasar) / casesSentToAlfaTraditional) * 100);

  // Check if Alfa ER is offline
  const alfa = facilities.find(f => f.id === 'fac-alfa');
  const isAlfaOffline = !alfa?.isOperational;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/50 to-slate-900 p-6 sm:p-8 rounded-3xl border border-indigo-500/40 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-xs font-bold mb-2">
              <Sliders className="w-4 h-4 text-indigo-400" />
              <span>ROUTING EXPLAINABILITY & SIMULATION LAB</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              مختبر التوجيه ومقارنة قبل / بعد (20 حالة افتراضية)
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              يقارن النموذج بين التوجيه التقليدي الأعمى (التوجه دائماً لأقرب مستشفى بغض النظر عن خطورة الحالة وازدحامها) وبين توجيه مسار الذكي (MIRE) الذي يخفف الضغط بنسبة <strong>61%</strong> عن طوارئ الحرم مع الحفاظ المطلق على حياة الحالات الحرجة.
            </p>
          </div>

          <button
            onClick={onResetFacilities}
            className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-bold flex items-center gap-2 transition-colors shrink-0"
          >
            <RefreshCcw className="w-3.5 h-3.5" />
            <span>إعادة ضبط المنشآت</span>
          </button>
        </div>

        {/* Big Impact Comparison Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 pt-6 border-t border-indigo-800/40">
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-red-500/30">
            <span className="text-[11px] font-bold text-red-400 block mb-1">
              التوجيه التقليدي (بدون مسار)
            </span>
            <div className="text-xl font-black text-white">18 من 20 حالة</div>
            <p className="text-[11px] text-slate-400 mt-1">
              تتجه لطوارئ مستشفى ألفا لمجرد أنه الأقرب (تكدس خانق 98%)
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/80 border border-emerald-500/30">
            <span className="text-[11px] font-bold text-emerald-400 block mb-1">
              مع توجيه مسار الذكي (MIRE)
            </span>
            <div className="text-xl font-black text-emerald-400">7 حالات فقط لطوارئ ألفا</div>
            <p className="text-[11px] text-slate-400 mt-1">
              حصر الطوارئ للحالات الحرجة وتوزيع 13 حالة على المراكز البديلة
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/80 border border-teal-500/30">
            <span className="text-[11px] font-bold text-teal-400 block mb-1">
              الأثر التشغيلي المحقق
            </span>
            <div className="text-xl font-black text-teal-300">-{reductionPercent}% تخفيف ضغط</div>
            <p className="text-[11px] text-slate-400 mt-1">
              مع صفر تأخير للحالات الحرجة التي تحتاج إنعاشاً فورياً
            </p>
          </div>
        </div>
      </div>

      {/* Facility Stress Testing & Shutdown Simulator */}
      <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Power className="w-4 h-4 text-amber-400" />
              <span>محاكاة تغير جاهزية المنشآت (Stress Testing & Resilience)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              جرّب إغلاق طوارئ مستشفى ألفا وشاهد كيف يعيد النظام حساب المسارات بأمان
            </p>
          </div>
          {isAlfaOffline && (
            <span className="px-3 py-1 rounded-full bg-red-500/20 text-red-300 border border-red-500/40 text-xs font-bold animate-pulse">
              ⚠️ طوارئ ألفا معطلة حالياً: تم تحويل المسارات البديلة تلقائياً!
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {facilities.map((fac) => (
            <div
              key={fac.id}
              className={`p-4 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                fac.isOperational
                  ? 'bg-slate-950 border-slate-800'
                  : 'bg-red-950/30 border-red-500/50'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${fac.isOperational ? 'bg-emerald-400' : 'bg-red-500'}`} />
                  <h4 className="text-xs font-bold text-white">{fac.nameAr}</h4>
                </div>
                <div className="text-[11px] text-slate-400">
                  {fac.isOperational ? `إشغال ${Math.round((fac.occupiedBeds / fac.totalBeds) * 100)}%` : 'خارج الخدمة (مغلقة مؤقتاً)'}
                </div>
              </div>

              <button
                onClick={() => onToggleFacilityStatus(fac.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors flex items-center gap-1.5 ${
                  fac.isOperational
                    ? 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-red-500/20 hover:text-red-300 hover:border-red-500/40'
                    : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                }`}
              >
                <Power className="w-3.5 h-3.5" />
                <span>{fac.isOperational ? 'تعطيل' : 'إعادة تشغيل'}</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* 20 Cases Breakdown Table */}
      <div className="bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-indigo-400" />
            <h3 className="text-lg font-bold text-white">
              مقارنة نتائج التوجيه للحالات الـ 20
            </h3>
          </div>

          <div className="flex items-center gap-2">
            {[
              { id: 'all', label: 'جميع الحالات (20)' },
              { id: 'high', label: '🔴 حرجة (7)' },
              { id: 'urgent', label: '🟠 عاجلة (5)' },
              { id: 'low', label: '🟢 بسيطة (8)' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilterAcuity(f.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                  filterAcuity === f.id
                    ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/60 font-bold'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Table Rows */}
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-3 px-3">#</th>
                <th className="py-3 px-3">وصف الحالة السريرية</th>
                <th className="py-3 px-3">الخطورة</th>
                <th className="py-3 px-3 text-red-400">التوجيه التقليدي (بدون مسار)</th>
                <th className="py-3 px-3 text-teal-400">توجيه مسار الذكي (MIRE)</th>
                <th className="py-3 px-3">تفسير قرار التوجيه والأمان</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredCases.map((c) => (
                <tr key={c.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-3 font-mono text-slate-500">{c.id}</td>
                  <td className="py-3 px-3 font-bold text-white">{c.descriptionAr}</td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded-full font-bold ${
                      c.acuity === 'high' ? 'bg-red-500/20 text-red-300' : c.acuity === 'urgent' ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'
                    }`}>
                      {c.acuity === 'high' ? 'حرج 🔴' : c.acuity === 'urgent' ? 'عاجل 🟠' : 'بسيط 🟢'}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-400">
                    <span className="line-through text-red-400/80">{c.traditionalChoice}</span>
                  </td>
                  <td className="py-3 px-3">
                    <span className="font-bold text-teal-300 bg-teal-500/10 px-2 py-1 rounded-lg border border-teal-500/30">
                      {isAlfaOffline && c.masarChoice.includes('ألفا') ? 'مستشفى بيتا العام (بديل طوارئ)' : c.masarChoice}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-400 max-w-xs">{c.reasonAr}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
