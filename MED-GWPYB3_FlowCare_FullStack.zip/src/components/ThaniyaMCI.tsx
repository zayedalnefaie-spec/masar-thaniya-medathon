import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Ambulance, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  Plus, 
  Hospital, 
  Flame, 
  Building2, 
  UserPlus, 
  RefreshCw, 
  Layers, 
  ArrowRight,
  Filter
} from 'lucide-react';
import { Facility, Language, MCICasualty, TriageTag, CasualtyStatus } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface ThaniyaMCIProps {
  currentLang: Language;
  facilities: Facility[];
  casualties: MCICasualty[];
  onAddCasualty: (casualty: MCICasualty) => void;
  onUpdateCasualtyStatus: (casualtyId: string, status: CasualtyStatus, facilityId?: string) => void;
  onUpdateFacilityCapacity: (facilityId: string, occupiedDelta: number, reservedDelta: number) => void;
}

export const ThaniyaMCI: React.FC<ThaniyaMCIProps> = ({
  currentLang,
  facilities,
  casualties,
  onAddCasualty,
  onUpdateCasualtyStatus,
  onUpdateFacilityCapacity
}) => {
  const t = TRANSLATIONS[currentLang];
  const [filterTag, setFilterTag] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  // New casualty form state
  const [newTag, setNewTag] = useState<TriageTag>('red');
  const [newDesc, setNewDesc] = useState<string>('إصابة صدرية ورضوض متعددة إثر التدافع');
  const [newCapability, setNewCapability] = useState<string>('trauma');
  const [newAge, setNewAge] = useState<MCICasualty['ageGroup']>('adult');
  const [newGender, setNewGender] = useState<MCICasualty['gender']>('male');
  const [newRespRate, setNewRespRate] = useState<number>(32);
  const [newPulse, setNewPulse] = useState<boolean>(true);
  const [newMental, setNewMental] = useState<MCICasualty['mentalStatus']>('cannot_follow');

  // Counts by tag
  const redCount = casualties.filter(c => c.tag === 'red').length;
  const yellowCount = casualties.filter(c => c.tag === 'yellow').length;
  const greenCount = casualties.filter(c => c.tag === 'green').length;
  const blackCount = casualties.filter(c => c.tag === 'black').length;

  const enRouteCount = casualties.filter(c => c.status === 'en_route').length;
  const deliveredCount = casualties.filter(c => c.status === 'delivered').length;

  // Filtered list
  const filteredCasualties = casualties.filter(c => {
    if (filterTag === 'all') return true;
    if (filterTag === 'en_route') return c.status === 'en_route';
    if (filterTag === 'delivered') return c.status === 'delivered';
    return c.tag === filterTag;
  });

  const getBestFacilityForCasualty = (casualty: MCICasualty) => {
    // Find facility that has the capability and is operational
    const matches = facilities.filter(f => f.isOperational && f.capabilities.includes(casualty.requiredCapability));
    if (matches.length === 0) return facilities.find(f => f.type === 'trauma_center') || facilities[0];
    
    // Sort by available beds (total - occupied - reserved) and travel time
    matches.sort((a, b) => {
      const availA = a.totalBeds - (a.occupiedBeds + a.reservedBeds);
      const availB = b.totalBeds - (b.occupiedBeds + b.reservedBeds);
      if (availA <= 0) return 1;
      if (availB <= 0) return -1;
      return a.travelTimeMinutes - b.travelTimeMinutes;
    });

    return matches[0];
  };

  const handleDispatchAmbulance = (casualty: MCICasualty) => {
    const targetFac = getBestFacilityForCasualty(casualty);
    // Mark as en_route
    onUpdateCasualtyStatus(casualty.id, 'en_route', targetFac.id);
    // Reserve bed: reservedBeds + 1
    onUpdateFacilityCapacity(targetFac.id, 0, 1);
  };

  const handleConfirmHandover = (casualty: MCICasualty) => {
    if (!casualty.assignedFacilityId) return;
    // Mark as delivered
    onUpdateCasualtyStatus(casualty.id, 'delivered');
    // Convert reserved to occupied: reserved - 1, occupied + 1
    onUpdateFacilityCapacity(casualty.assignedFacilityId, 1, -1);
  };

  const handleCreateCasualty = (e: React.FormEvent) => {
    e.preventDefault();
    const id = `THN-${100 + casualties.length + 1}`;
    const newCas: MCICasualty = {
      id,
      incidentId: 'INC-2026-01',
      tag: newTag,
      ageGroup: newAge,
      gender: newGender,
      injuryDescription: newDesc,
      injuryDescriptionAr: newDesc,
      respiratoryRate: newRespRate,
      radialPulsePresent: newPulse,
      mentalStatus: newMental,
      requiredCapability: newCapability,
      status: 'field_triage',
      reportedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    onAddCasualty(newCas);
    setShowAddModal(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* MCI Header Banner */}
      <div className="bg-gradient-to-r from-red-950/80 via-slate-900 to-amber-950/60 p-6 sm:p-8 rounded-3xl border border-red-500/40 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/20 text-red-300 border border-red-500/40 text-xs font-bold mb-2">
              <ShieldAlert className="w-4 h-4 text-red-400 animate-pulse" />
              <span>نظام إدارة الإصابات الجماعية الميداني (Thaniya MCI Coordination)</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2">
              ثانية | تتبع وتوزيع مصابي الحوادث الجماعية
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              يربط فرق الإسعاف الميداني (الهلال الأحمر) بمركز القيادة والمستشفيات، ويحجز السعة السريرية فور انطلاق سيارة الإسعاف لمنع تكدس المصابين في مستشفى واحد مع تأكيد الاستلام دون احتساب مزدوج.
            </p>
          </div>

          {/* Quick Action Button */}
          <button
            onClick={() => setShowAddModal(true)}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-black text-xs flex items-center gap-2 shadow-xl shadow-red-600/30 transition-all shrink-0"
          >
            <UserPlus className="w-4 h-4" />
            <span>تسجيل مصاب ميداني جديد (START Triage)</span>
          </button>
        </div>

        {/* Incident Summary Bar */}
        <div className="mt-6 pt-5 border-t border-red-800/40 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <span className="font-bold text-white">الحادث النشط:</span>
            <span className="px-2.5 py-0.5 rounded-md bg-slate-800 text-red-300 font-mono font-bold">
              INC-2026-01: تدافع محطة قطار المشاعر (منى 3)
            </span>
          </div>
          <div className="flex items-center gap-4 text-slate-400 font-medium">
            <span>الحالات قيد النقل: <strong className="text-amber-400">{enRouteCount}</strong></span>
            <span>•</span>
            <span>تم استلامها في المستشفى: <strong className="text-emerald-400">{deliveredCount}</strong></span>
          </div>
        </div>
      </div>

      {/* START Triage Quick Counters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {/* Red Tag */}
        <div 
          onClick={() => setFilterTag(filterTag === 'red' ? 'all' : 'red')}
          className={`p-5 rounded-2xl border cursor-pointer transition-all ${
            filterTag === 'red' 
              ? 'bg-red-500/20 border-red-500 ring-2 ring-red-500/50 shadow-lg' 
              : 'bg-slate-900 border-red-500/40 hover:bg-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-red-400 flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
              أحمر (P1 - Immediate)
            </span>
            <span className="text-2xl font-black text-white">{redCount}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            حالات مهددة للحياة فوراً (انسداد مجرى هوائي، نزيف حاد، صدمة)
          </p>
        </div>

        {/* Yellow Tag */}
        <div 
          onClick={() => setFilterTag(filterTag === 'yellow' ? 'all' : 'yellow')}
          className={`p-5 rounded-2xl border cursor-pointer transition-all ${
            filterTag === 'yellow' 
              ? 'bg-amber-500/20 border-amber-500 ring-2 ring-amber-500/50 shadow-lg' 
              : 'bg-slate-900 border-amber-500/40 hover:bg-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-400">
              أصفر (P2 - Delayed)
            </span>
            <span className="text-2xl font-black text-white">{yellowCount}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            إصابات بليغة لكن مستقرة مؤقتاً (كسور مركبة، جروح عميقة)
          </p>
        </div>

        {/* Green Tag */}
        <div 
          onClick={() => setFilterTag(filterTag === 'green' ? 'all' : 'green')}
          className={`p-5 rounded-2xl border cursor-pointer transition-all ${
            filterTag === 'green' 
              ? 'bg-emerald-500/20 border-emerald-500 ring-2 ring-emerald-500/50 shadow-lg' 
              : 'bg-slate-900 border-emerald-500/40 hover:bg-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-400">
              أخضر (P3 - Minimal)
            </span>
            <span className="text-2xl font-black text-white">{greenCount}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            جرحى يمشون بشكل مستقل (سحجات، رضوح خفيفة)
          </p>
        </div>

        {/* Black Tag */}
        <div 
          onClick={() => setFilterTag(filterTag === 'black' ? 'all' : 'black')}
          className={`p-5 rounded-2xl border cursor-pointer transition-all ${
            filterTag === 'black' 
              ? 'bg-slate-800 border-slate-500 ring-2 ring-slate-500/50 shadow-lg' 
              : 'bg-slate-900 border-slate-700 hover:bg-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400">
              أسود (P4 - Expectant)
            </span>
            <span className="text-2xl font-black text-white">{blackCount}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            انعدام التنفس والنبض بعد فتح المجرى الهوائي
          </p>
        </div>
      </div>

      {/* Hospital Real-Time Capacity & En-Route Reservations */}
      <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Hospital className="w-5 h-5 text-teal-400" />
              <span>جاهزية المستشفيات لاستقبال المصابين وحجز السعة السريرية</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              تظهر الأسرّة المحجوزة للمصابين المنقولين حالياً باللون البرتقالي لمنع التوزيع المزدوج
            </p>
          </div>
          <span className="text-xs text-slate-400 bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700 font-mono">
            Simulated Feed: Real-time Demo
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {facilities.filter(f => f.type !== 'virtual_hub').map((fac) => {
            const availableBeds = Math.max(0, fac.totalBeds - (fac.occupiedBeds + fac.reservedBeds));
            const occupancyPct = Math.round((fac.occupiedBeds / fac.totalBeds) * 100);
            const isStale = fac.lastUpdatedMinutesAgo > 15;

            return (
              <div 
                key={fac.id}
                className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-xs font-bold text-white">{fac.nameAr}</h4>
                    <span className="text-[11px] text-slate-400">{fac.zoneAr}</span>
                  </div>
                  {isStale && (
                    <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold shrink-0">
                      بيانات قديمة ⚠️
                    </span>
                  )}
                </div>

                {/* Bed Status Visual */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-400">الأسرّة المتاحة:</span>
                    <span className={`font-mono font-bold ${availableBeds > 5 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {availableBeds} سرير متاح
                    </span>
                  </div>

                  {/* Segmented capacity bar */}
                  <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden flex">
                    {/* Occupied */}
                    <div 
                      style={{ width: `${(fac.occupiedBeds / fac.totalBeds) * 100}%` }}
                      className="bg-red-500/80 h-full"
                      title={`مشغول: ${fac.occupiedBeds}`}
                    />
                    {/* Reserved en-route */}
                    <div 
                      style={{ width: `${(fac.reservedBeds / fac.totalBeds) * 100}%` }}
                      className="bg-amber-400 h-full animate-pulse"
                      title={`محجوز قيد النقل: ${fac.reservedBeds}`}
                    />
                  </div>

                  <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                    <span>مشغول: {fac.occupiedBeds} ({occupancyPct}%)</span>
                    <span className="text-amber-300 font-bold">محجوز قيد النقل: {fac.reservedBeds}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800/80">
                  <span>زمن النقل: <strong className="text-white">{fac.travelTimeMinutes} دقيقة</strong></span>
                  <div className="flex gap-1">
                    {fac.capabilities.slice(0, 2).map((cap, i) => (
                      <span key={i} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-teal-300 font-semibold">
                        {cap}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Casualties Feed & Coordination Table */}
      <div className="bg-slate-900 p-6 rounded-3xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-teal-400" />
            <h3 className="text-base font-bold text-white">
              سجل المصابين الميداني وحالة الإخلاء
            </h3>
            <span className="text-xs text-slate-400">({filteredCasualties.length} مصاب)</span>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-1.5">
            {[
              { id: 'all', label: 'الكل' },
              { id: 'red', label: '🔴 حرج (Red)' },
              { id: 'yellow', label: '🟡 متوسط (Yellow)' },
              { id: 'green', label: '🟢 طفيف (Green)' },
              { id: 'en_route', label: '🚑 قيد النقل' },
              { id: 'delivered', label: '✓ تم الاستلام' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilterTag(f.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                  filterTag === f.id
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/60 shadow-sm'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Casualties Cards / Table */}
        <div className="space-y-3">
          {filteredCasualties.map((cas) => {
            const assignedFac = facilities.find(f => f.id === cas.assignedFacilityId);
            const recommendedFac = getBestFacilityForCasualty(cas);

            return (
              <div 
                key={cas.id}
                className="p-5 rounded-2xl bg-slate-950 border border-slate-800/90 hover:border-slate-700 transition-all flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4"
              >
                {/* Casualty ID & Triage Tag */}
                <div className="flex items-start gap-3.5">
                  <div className={`p-3 rounded-2xl shrink-0 text-center font-mono font-black text-sm border ${
                    cas.tag === 'red'
                      ? 'bg-red-500/20 text-red-300 border-red-500/50'
                      : cas.tag === 'yellow'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                        : cas.tag === 'green'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
                          : 'bg-slate-800 text-slate-300 border-slate-600'
                  }`}>
                    <div>{cas.id}</div>
                    <div className="text-[10px] uppercase">{cas.tag}</div>
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white">
                        {currentLang === 'ar' ? cas.injuryDescriptionAr : cas.injuryDescription}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        ({cas.reportedAt})
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-1">
                      <span>الفئة: <strong className="text-slate-200">{cas.ageGroup} / {cas.gender}</strong></span>
                      <span>•</span>
                      <span>معدل التنفس: <strong className="text-slate-200">{cas.respiratoryRate ?? 'N/A'}/د</strong></span>
                      <span>•</span>
                      <span>النبض الكعبري: <strong className={cas.radialPulsePresent ? 'text-emerald-400' : 'text-red-400'}>
                        {cas.radialPulsePresent ? 'محسوس' : 'غير محسوس (صدمة)'}
                      </strong></span>
                      <span>•</span>
                      <span>القدرة المطلوبة: <strong className="text-teal-400">{cas.requiredCapability}</strong></span>
                    </div>
                  </div>
                </div>

                {/* Routing & Action Controls */}
                <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto justify-between lg:justify-end border-t lg:border-t-0 pt-3 lg:pt-0 border-slate-800">
                  {/* Status Indicator */}
                  <div>
                    {cas.status === 'field_triage' && (
                      <span className="text-xs px-2.5 py-1 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 font-semibold">
                        بانتظار التوجيه الميداني
                      </span>
                    )}
                    {cas.status === 'en_route' && (
                      <span className="text-xs px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold flex items-center gap-1.5 animate-pulse">
                        <Ambulance className="w-3.5 h-3.5" />
                        <span>قيد النقل إلى: {assignedFac?.nameAr}</span>
                      </span>
                    )}
                    {cas.status === 'delivered' && (
                      <span className="text-xs px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold flex items-center gap-1.5">
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>تم الاستلام في: {assignedFac?.nameAr}</span>
                      </span>
                    )}
                  </div>

                  {/* Actions */}
                  {cas.status === 'field_triage' && (
                    <button
                      onClick={() => handleDispatchAmbulance(cas)}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-teal-600/30 transition-all"
                    >
                      <Ambulance className="w-3.5 h-3.5" />
                      <span>توجيه وحجز سرير في ({recommendedFac.nameAr})</span>
                    </button>
                  )}

                  {cas.status === 'en_route' && (
                    <button
                      onClick={() => handleConfirmHandover(cas)}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-600/30 transition-all"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>تأكيد استلام المستشفى (Handover)</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* New Casualty Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-red-400" />
                  <span>تسجيل مصاب جديد بروتوكول START Triage</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  تصنيف سريع بالميدان وتوجيه ذكي مبني على القدرات الطبية
                </p>
              </div>
              <button 
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateCasualty} className="space-y-4">
              {/* Triage Tag Selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  تصنيف الفرز (Triage Category)
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { tag: 'red', label: 'أحمر (P1)', color: 'bg-red-500/20 text-red-300 border-red-500/60' },
                    { tag: 'yellow', label: 'أصفر (P2)', color: 'bg-amber-500/20 text-amber-300 border-amber-500/60' },
                    { tag: 'green', label: 'أخضر (P3)', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/60' },
                    { tag: 'black', label: 'أسود (P4)', color: 'bg-slate-800 text-slate-300 border-slate-600' },
                  ].map((item) => (
                    <button
                      key={item.tag}
                      type="button"
                      onClick={() => setNewTag(item.tag as TriageTag)}
                      className={`p-2.5 rounded-xl text-xs font-bold border transition-all text-center ${
                        newTag === item.tag ? `${item.color} ring-2 ring-white/20` : 'bg-slate-950 text-slate-400 border-slate-800'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Injury Description */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  وصف الإصابة الميدانية
                </label>
                <input
                  type="text"
                  required
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-teal-500"
                  placeholder="مثال: اشتباه كسر حوضي ونزيف حاد"
                />
              </div>

              {/* Required Capability */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  القدرة السريرية المطلوبة (Specialized Capability Match)
                </label>
                <select
                  value={newCapability}
                  onChange={(e) => setNewCapability(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-teal-500"
                >
                  <option value="trauma">طوارئ وإصابات عامة (Emergency Trauma)</option>
                  <option value="level1_trauma">مركز إصابات متقدم مستوى 1 (Level 1 Trauma)</option>
                  <option value="burn_unit">وحدة حروق متخصصة (Burn Center)</option>
                  <option value="cardiac">إنعاش وقسطرة قلبية (Cath Lab)</option>
                  <option value="minor_trauma">عناية بالجروح البسيطة (Minor Trauma)</option>
                </select>
              </div>

              {/* Quick Vitals */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    معدل التنفس (دقيقة)
                  </label>
                  <input
                    type="number"
                    value={newRespRate}
                    onChange={(e) => setNewRespRate(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    النبض الكعبري
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setNewPulse(true)}
                      className={`flex-1 py-2 rounded-xl text-xs font-bold border ${newPulse ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500' : 'bg-slate-950 text-slate-400 border-slate-800'}`}
                    >
                      محسوس
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewPulse(false)}
                      className={`flex-1 py-2 rounded-xl text-xs font-bold border ${!newPulse ? 'bg-red-500/20 text-red-300 border-red-500' : 'bg-slate-950 text-slate-400 border-slate-800'}`}
                    >
                      معدوم
                    </button>
                  </div>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 text-white font-bold text-xs shadow-lg shadow-red-600/30"
                >
                  حفظ وتسجيل المصاب
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
