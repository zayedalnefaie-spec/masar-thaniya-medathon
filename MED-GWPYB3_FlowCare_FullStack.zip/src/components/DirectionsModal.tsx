import React from 'react';
import { X, MapPin, Clock, ExternalLink, Navigation, PhoneCall, Building2, CheckCircle2 } from 'lucide-react';
import { Facility, Language } from '../types';

interface DirectionsModalProps {
  facility: Facility | null;
  onClose: () => void;
  currentLang: Language;
}

export const DirectionsModal: React.FC<DirectionsModalProps> = ({
  facility,
  onClose,
  currentLang
}) => {
  if (!facility) return null;

  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${facility.lat},${facility.lng}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-teal-500/20 text-teal-400">
              <Navigation className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                مسار التوجه الملاحي إلى المنشأة
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {currentLang === 'ar' ? facility.nameAr : facility.name}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-xl text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Route Details Box */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">الموقع الجغرافي:</span>
            <span className="font-bold text-white">{currentLang === 'ar' ? facility.zoneAr : facility.zone}</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">المسافة المقدرة:</span>
            <span className="font-bold text-teal-300 font-mono">{facility.distanceKm} كم</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">زمن الوصول سيرًا/مركبة:</span>
            <span className="font-bold text-teal-300 font-mono">{facility.travelTimeMinutes} دقيقة</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">نسبة الإشغال الحالية:</span>
            <span className="font-bold text-amber-400 font-mono">
              {Math.round((facility.occupiedBeds / facility.totalBeds) * 100)}%
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
          <a
            href={googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-teal-600/30 transition-all text-center"
          >
            <ExternalLink className="w-4 h-4" />
            <span>فتح الخريطة في خرائط Google</span>
          </a>

          {facility.contactNumber && (
            <a
              href={`tel:${facility.contactNumber}`}
              className="w-full sm:w-auto py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center justify-center gap-2"
            >
              <PhoneCall className="w-4 h-4 text-teal-400" />
              <span>اتصال ({facility.contactNumber})</span>
            </a>
          )}
        </div>
      </div>
    </div>
  );
};
