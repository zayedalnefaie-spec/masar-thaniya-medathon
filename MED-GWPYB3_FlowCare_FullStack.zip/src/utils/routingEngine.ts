import { Facility, PatientTriageInput, TriageEvaluation } from '../types';

export function evaluatePatientTriage(input: PatientTriageInput, facilities: Facility[]): TriageEvaluation {
  const redFlagsTriggered: string[] = [];
  const reasonsAr: string[] = [];
  const reasonsEn: string[] = [];

  // Check red flags (yes or unsure triggers safety escalation)
  const rf = input.redFlags;
  if (rf.difficultyBreathingSevere === true || rf.difficultyBreathingSevere === 'unsure') {
    redFlagsTriggered.push('difficultyBreathingSevere');
    reasonsAr.push('صعوبة حادة في التنفس أثناء الراحة أو عدم التأكد من استقرار المجرى الهوائي');
    reasonsEn.push('Severe shortness of breath at rest or unconfirmed airway safety');
  }
  if (rf.chestPainSevere === true || rf.chestPainSevere === 'unsure') {
    redFlagsTriggered.push('chestPainSevere');
    reasonsAr.push('ألم أو ضغط شديد بالصدر يمتد للذراع/الفك (اشتباه أزمة قلبية حادة)');
    reasonsEn.push('Crushing chest pain radiating to arm/jaw (acute coronary suspect)');
  }
  if (rf.lossOfConsciousness === true || rf.lossOfConsciousness === 'unsure') {
    redFlagsTriggered.push('lossOfConsciousness');
    reasonsAr.push('فقدان وعي أو تشوش ذهني حاد مفاجئ');
    reasonsEn.push('Loss of consciousness or acute sudden confusion');
  }
  if (rf.severeBleeding === true || rf.severeBleeding === 'unsure') {
    redFlagsTriggered.push('severeBleeding');
    reasonsAr.push('نزيف حاد نشط لا يتوقف بالضغط المباشر');
    reasonsEn.push('Active severe bleeding unstopped by pressure');
  }
  if (rf.unableToWalkOrDrink === true || rf.unableToWalkOrDrink === 'unsure') {
    redFlagsTriggered.push('unableToWalkOrDrink');
    reasonsAr.push('عجز تام عن المشي أو شرب السوائل مع تدهور العلامات الحيوية');
    reasonsEn.push('Inability to walk or tolerate oral fluids with systemic deterioration');
  }

  if (rf.suddenConfusion === true || rf.suddenConfusion === 'unsure') {redFlagsTriggered.push('suddenConfusion');reasonsEn.push('Sudden confusion requires emergency assessment');reasonsAr.push('تشوش مفاجئ يستدعي تقييمًا إسعافيًا');}

  // Symptom specific logic
  const isHighRiskSymptom = ['chest_pain', 'breathing', 'bleeding'].includes(input.mainSymptom);
  const isMildSymptom = input.mainSymptom === 'mild_cold_throat';

  let acuity: 'high' | 'urgent' | 'low' = 'low';
  let acuityScore = 1;

  if (redFlagsTriggered.length > 0 || (isHighRiskSymptom && input.severity >= 4)) {
    acuity = 'high';
    acuityScore = 3;
  } else if (input.severity >= 3 || input.mainSymptom === 'heat_fever' || input.mainSymptom === 'injury_trauma' || input.mainSymptom === 'vomiting_diarrhea') {
    acuity = 'urgent';
    acuityScore = 2;
  } else {
    acuity = 'low';
    acuityScore = 1;
  }

  // MIRE Smart Routing Engine Logic
  // Filter active operational facilities
  const operational = facilities.filter(f => f.isOperational);

  if(!operational.length) throw Object.assign(new Error('No operational facilities; coordinator review required'),{status:409});
  let recommended: Facility;
  let alternative: Facility | undefined;
  let ruleApplied = '';
  let ruleAppliedAr = '';
  let whyChosen = '';
  let whyChosenAr = '';
  const whyOthersExcluded: { facilityId: string; reason: string; reasonAr: string }[] = [];

  if (acuity === 'high') {
    // RULE 1: CLINICAL URGENCY OVERRIDES CONGESTION
    // Find facilities with ER capability and shortest travel time
    const erCapable = operational.filter(f => f.erAccepting && f.capabilities.includes('er'));
    erCapable.sort((a, b) => a.travelTimeMinutes - b.travelTimeMinutes);

    if(!erCapable.length) throw Object.assign(new Error('No capable emergency facility; manual emergency escalation required'),{status:409});
    recommended = erCapable[0];
    alternative = erCapable[1] || operational.find(f => f.id === 'fac-specialized');

    ruleApplied = 'Clinical Urgency Rule: High-acuity presentation demands immediate emergency care. System overrides ED congestion to minimize transit time.';
    ruleAppliedAr = 'قاعدة الأمان السريري الحاكم: الحالة عالية الخطورة تتطلب تدخلاً إسعافياً عاجلاً، تم إلغاء قيود الازدحام لتقليل وقت الوصول لأقرب طوارئ مجهزة.';

    whyChosen = `${recommended.name} is the fastest reachable emergency department (${recommended.travelTimeMinutes} min) with active resuscitation and ICU capabilities, regardless of its ${Math.round((recommended.occupiedBeds / recommended.totalBeds) * 100)}% load.`;
    whyChosenAr = `${recommended.nameAr} هي أقرب منشأة طوارئ مجهزة (${recommended.travelTimeMinutes} دقائق) بقدرات إنعاش وعناية مركزة، وتم اختيارها فوراً رغم ارتفاع نسبة الإشغال (${Math.round((recommended.occupiedBeds / recommended.totalBeds) * 100)}%) لأن سلامة المريض مقدمة على الازدحام.`;

    // Explain why primary centers were excluded
    operational.forEach(f => {
      if (f.id !== recommended.id) {
        if (!f.capabilities.includes('er')) {
          whyOthersExcluded.push({
            facilityId: f.id,
            reason: `Excluded because it lacks advanced resuscitation / emergency trauma equipment required for High-Risk cases.`,
            reasonAr: `استُبعدت لعدم توفر تجهيزات الإنعاش القلبي والرعاية الحرجة المطلوبة للحالات الخطرة.`
          });
        } else if (f.travelTimeMinutes > recommended.travelTimeMinutes) {
          whyOthersExcluded.push({
            facilityId: f.id,
            reason: `Travel time (${f.travelTimeMinutes} min) is longer than recommended emergency facility (${recommended.travelTimeMinutes} min).`,
            reasonAr: `زمن الوصول (${f.travelTimeMinutes} دقيقة) أطول من المنشأة المختارة (${recommended.travelTimeMinutes} دقائق).`
          });
        }
      }
    });

  } else if (acuity === 'urgent') {
    // RULE 2: URGENT BALANCED ROUTING
    // Match capability and balance travel time vs capacity
    const urgentCapable = operational.filter(f => 
      f.capabilities.includes('urgent_care') || 
      f.capabilities.includes('er') || 
      f.capabilities.includes('heat_exhaustion')
    );

    // Score based on travel time + capacity penalty
    urgentCapable.sort((a, b) => {
      const loadA = (a.occupiedBeds + a.reservedBeds) / a.totalBeds;
      const loadB = (b.occupiedBeds + b.reservedBeds) / b.totalBeds;
      // High load adds virtual travel time penalty
      const scoreA = a.travelTimeMinutes + (loadA > 0.85 ? 15 : loadA * 6);
      const scoreB = b.travelTimeMinutes + (loadB > 0.85 ? 15 : loadB * 6);
      return scoreA - scoreB;
    });

    if(!urgentCapable.length) throw Object.assign(new Error('No urgent-capable facility; coordinator review required'),{status:409});
    recommended = urgentCapable[0];
    alternative = urgentCapable[1];

    ruleApplied = 'Balanced Urgent Routing: Directs patient to an urgent-capable facility optimizing both travel time and bed availability.';
    ruleAppliedAr = 'توجيه متوازن للحالات العاجلة: توجيه الحالة لمنشأة مؤهلة مع الموازنة بين سرعة الوصول وتوافر السعة السريرية.';

    whyChosen = `${recommended.name} provides appropriate urgent care within ${recommended.travelTimeMinutes} minutes while maintaining safe operational capacity.`;
    whyChosenAr = `يوفر ${recommended.nameAr} الرعاية العاجلة المناسبة خلال ${recommended.travelTimeMinutes} دقائق مع جاهزية سريرية مناسبة.`;

    operational.forEach(f => {
      if (f.id !== recommended.id && (f.occupiedBeds / f.totalBeds) > 0.85) {
        whyOthersExcluded.push({
          facilityId: f.id,
          reason: `High congestion (${Math.round((f.occupiedBeds / f.totalBeds) * 100)}%) avoided to reduce waiting time for non-life-threatening conditions.`,
          reasonAr: `تم تجنبها نظراً لارتفاع نسبة الازدحام (${Math.round((f.occupiedBeds / f.totalBeds) * 100)}%) وتفادياً لانتظار طويل لحالة غير مهددة للحياة فوراً.`
        });
      }
    });

  } else {
    // RULE 3: LOW-ACUITY DIVERSION FROM ED
    // Strongly prioritize Primary Care Center (Delta) or Virtual Seha
    const primaryOrVirtual = operational.filter(f => 
      f.type === 'primary_center' || f.type === 'virtual_hub'
    );

    // Prefer Delta or Virtual based on load & convenience
    const delta = operational.find(f => f.id === 'fac-delta');
    const virtual = operational.find(f => f.id === 'fac-virtual');

    recommended = delta || primaryOrVirtual[0] || operational[0];
    alternative = virtual;

    ruleApplied = 'Emergency Diversion Protocol: Low-acuity cases are routed to primary and virtual care to preserve hospital emergency beds for critical emergencies.';
    ruleAppliedAr = 'بروتوكول تفريغ الطوارئ الذكي: توجيه الحالات البسيطة إلى مراكز الرعاية الأولية والاستشارات الافتراضية لمنع إشغال أسرّة الطوارئ وحفظها للحالات الحرجة.';

    whyChosen = `${recommended.name} has low occupancy (${Math.round((recommended.occupiedBeds / recommended.totalBeds) * 100)}%) with zero ED wait time, perfectly suited for primary walk-in evaluation.`;
    whyChosenAr = `يتميز ${recommended.nameAr} بنسبة إشغال منخفضة (${Math.round((recommended.occupiedBeds / recommended.totalBeds) * 100)}%) دون طوابير انتظار الطوارئ، وهو الخيار الأنسب والمريح لفحص الحالة.`;

    // Explicitly explain why Alfa was excluded!
    const alfa = operational.find(f => f.id === 'fac-alfa');
    if (alfa) {
      whyOthersExcluded.push({
        facilityId: alfa.id,
        reason: `Hospital Alfa ED is operating at ${Math.round((alfa.occupiedBeds / alfa.totalBeds) * 100)}% capacity. Routing low-acuity cases here causes severe delays and depletes resuscitation capacity.`,
        reasonAr: `طوارئ مستشفى ألفا تعمل بطاقة ${Math.round((alfa.occupiedBeds / alfa.totalBeds) * 100)}%، وتوجيه حالة بسيطة لها يسبب انتظاراً غير مبرر ويستنزف أسرّة الحالات الخطرة.`
      });
    }
  }

  return {
    acuity,
    acuityScore,
    reasons: reasonsEn.length > 0 ? reasonsEn : ['General evaluation based on reported symptom severity and duration.'],
    reasonsAr: reasonsAr.length > 0 ? reasonsAr : ['تقييم عام مستند إلى شدة الأعراض وطبيعة الشكوى الصحية.'],
    isRedFlagTriggered: redFlagsTriggered.length > 0,
    recommendedFacility: recommended,
    alternativeFacility: alternative,
    virtualOptionAvailable: true,
    decisionExplanation: {
      ruleApplied,
      ruleAppliedAr,
      whyChosen,
      whyChosenAr,
      whyOthersExcluded
    }
  };
}
