import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, onAuthStateChanged, User } from 'firebase/auth';
import firebaseConfig from '../firebase-applet-config.json';

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

let authReadyPromise: Promise<User | null> | null = null;

export function ensureAnonymousUser(): Promise<User | null> {
  if (authReadyPromise) return authReadyPromise;

  authReadyPromise = new Promise((resolve) => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      unsubscribe();
      if (user) {
        resolve(user);
      } else {
        try {
          const cred = await signInAnonymously(auth);
          resolve(cred.user);
        } catch (err: any) {
          console.warn('[Firebase Auth] Anonymous sign-in disabled or failed:', err?.code, err?.message);
          resolve(null);
        }
      }
    });
  });

  return authReadyPromise;
}

export async function getIdToken(): Promise<string | null> {
  try {
    const user = auth.currentUser || (await ensureAnonymousUser());
    if (!user) return null;
    return await user.getIdToken();
  } catch (err) {
    return null;
  }
}
