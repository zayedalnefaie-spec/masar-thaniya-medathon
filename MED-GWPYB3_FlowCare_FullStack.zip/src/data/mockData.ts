import { Facility, MCICasualty, SurgePrediction } from '../types';

export const INITIAL_FACILITIES: Facility[] = [
  {
    id: 'fac-alfa',
    name: 'Haram Emergency Hospital (Alfa)',
    nameAr: 'مستشفى الحرم للطوارئ (ألفا)',
    type: 'emergency_hospital',
    zone: 'Central Haram Plaza',
    zoneAr: 'المنطقة المركزية - ساحات الحرم',
    distanceKm: 0.8,
    travelTimeMinutes: 4,
    totalBeds: 120,
    occupiedBeds: 110, // 91.6% capacity
    reservedBeds: 2,
    capabilities: ['er', 'icu', 'trauma', 'cardiac', 'resuscitation'],
    isOperational: true,
    erAccepting: true,
    lastUpdatedMinutesAgo: 3,
    contactNumber: '012-5501000',
    lat: 21.4225,
    lng: 39.8262
  },
  {
    id: 'fac-beta',
    name: 'Mina Al-Wadi General Hospital (Beta)',
    nameAr: 'مستشفى منى الوادي العام (بيتا)',
    type: 'general_hospital',
    zone: 'Mina Valley Zone 2',
    zoneAr: 'مشعر منى - الوادي',
    distanceKm: 4.2,
    travelTimeMinutes: 11,
    totalBeds: 180,
    occupiedBeds: 112, // 62.2% capacity
    reservedBeds: 3,
    capabilities: ['er', 'icu', 'trauma', 'heat_exhaustion', 'general_surgery'],
    isOperational: true,
    erAccepting: true,
    lastUpdatedMinutesAgo: 6,
    contactNumber: '012-5562000',
    lat: 21.4133,
    lng: 39.8821
  },
  {
    id: 'fac-gamma',
    name: 'North Jamarat Urgent Health Center (Gamma)',
    nameAr: 'مركز صحي شمال الجمرات العاجل (جاما)',
    type: 'primary_center',
    zone: 'Jamarat Plaza',
    zoneAr: 'منطقة جسر الجمرات',
    distanceKm: 2.1,
    travelTimeMinutes: 7,
    totalBeds: 45,
    occupiedBeds: 35, // 77.7%
    reservedBeds: 1,
    capabilities: ['urgent_care', 'hydration', 'minor_trauma', 'pharmacy'],
    isOperational: true,
    erAccepting: false,
    lastUpdatedMinutesAgo: 5,
    contactNumber: '012-5583100',
    lat: 21.4208,
    lng: 39.8715
  },
  {
    id: 'fac-delta',
    name: 'Al-Aziziyah Primary Care & Walk-in (Delta)',
    nameAr: 'مركز صحي العزيزية للرعاية الأولية (دلتا)',
    type: 'primary_center',
    zone: 'Al-Aziziyah District',
    zoneAr: 'حي العزيزية الجنوبي',
    distanceKm: 3.8,
    travelTimeMinutes: 9,
    totalBeds: 50,
    occupiedBeds: 16, // 32% (Available!)
    reservedBeds: 0,
    capabilities: ['primary_care', 'walk_in', 'pharmacy', 'telemedicine', 'cold_fever'],
    isOperational: true,
    erAccepting: false,
    lastUpdatedMinutesAgo: 4,
    contactNumber: '012-5574000',
    lat: 21.4050,
    lng: 39.8510
  },
  {
    id: 'fac-virtual',
    name: 'Virtual Seha Hospital Hub (MOH 937)',
    nameAr: 'مستشفى صحة الافتراضي (خدمة 937)',
    type: 'virtual_hub',
    zone: 'Cloud Care / Nationwide',
    zoneAr: 'الرعاية السحابية الافتراضية / فورية',
    distanceKm: 0,
    travelTimeMinutes: 1,
    totalBeds: 9999,
    occupiedBeds: 1420,
    reservedBeds: 0,
    capabilities: ['telemedicine', 'multilingual_consult', 'e_prescription', 'triage_followup'],
    isOperational: true,
    erAccepting: false,
    lastUpdatedMinutesAgo: 1,
    contactNumber: '937',
    lat: 21.4225,
    lng: 39.8262
  },
  {
    id: 'fac-specialized',
    name: 'Al-Noor Specialist Hospital (Level 1 Trauma)',
    nameAr: 'مستشفى النور التخصصي (مركز إصابات مستوى 1)',
    type: 'trauma_center',
    zone: 'Makkah Third Ring Road',
    zoneAr: 'الطريق الدائري الثالث - مكة',
    distanceKm: 6.9,
    travelTimeMinutes: 16,
    totalBeds: 320,
    occupiedBeds: 245, // 76.5%
    reservedBeds: 4,
    capabilities: ['level1_trauma', 'burn_unit', 'neurosurgery', 'icu', 'cath_lab'],
    isOperational: true,
    erAccepting: true,
    lastUpdatedMinutesAgo: 2,
    contactNumber: '012-5665000',
    lat: 21.3912,
    lng: 39.8320
  }
];

export const INITIAL_CASUALTIES: MCICasualty[] = [
  {
    id: 'THN-101',
    incidentId: 'INC-2026-01',
    tag: 'red',
    ageGroup: 'elderly',
    gender: 'male',
    injuryDescription: 'Tension pneumothorax, severe respiratory distress after crowd surge',
    injuryDescriptionAr: 'استرواح صدري ضاغط وضيق تنفس حاد إثر التدافع',
    respiratoryRate: 36,
    radialPulsePresent: true,
    mentalStatus: 'cannot_follow',
    requiredCapability: 'trauma',
    assignedFacilityId: 'fac-alfa',
    assignedAmbulanceId: 'AMB-14',
    status: 'en_route',
    reportedAt: '10:14',
    enRouteAt: '10:19'
  },
  {
    id: 'THN-102',
    incidentId: 'INC-2026-01',
    tag: 'red',
    ageGroup: 'adult',
    gender: 'female',
    injuryDescription: '2nd-degree thermal burns covering 30% TBSA & inhalation risk',
    injuryDescriptionAr: 'حروق من الدرجة الثانية بنسبة 30% مع اشتباه استنشاق دخان',
    respiratoryRate: 24,
    radialPulsePresent: true,
    mentalStatus: 'can_follow_commands',
    requiredCapability: 'burn_unit',
    assignedFacilityId: 'fac-specialized',
    assignedAmbulanceId: 'AMB-08',
    status: 'en_route',
    reportedAt: '10:16',
    enRouteAt: '10:22'
  },
  {
    id: 'THN-103',
    incidentId: 'INC-2026-01',
    tag: 'yellow',
    ageGroup: 'adult',
    gender: 'male',
    injuryDescription: 'Closed fracture of right tibia/fibula, hemodynamically stable',
    injuryDescriptionAr: 'كسر مغلق في عظمة الساق اليمنى، العلامات الحيوية مستقرة',
    respiratoryRate: 18,
    radialPulsePresent: true,
    mentalStatus: 'can_follow_commands',
    requiredCapability: 'general_surgery',
    assignedFacilityId: 'fac-beta',
    assignedAmbulanceId: 'AMB-22',
    status: 'assigned',
    reportedAt: '10:18'
  },
  {
    id: 'THN-104',
    incidentId: 'INC-2026-01',
    tag: 'green',
    ageGroup: 'adult',
    gender: 'female',
    injuryDescription: 'Superficial lacerations, mild contusion, walking independently',
    injuryDescriptionAr: 'سحجات سطحية ورضوض طفيفة، قادرة على المشي بمفردها',
    respiratoryRate: 16,
    radialPulsePresent: true,
    mentalStatus: 'can_follow_commands',
    requiredCapability: 'minor_trauma',
    assignedFacilityId: 'fac-gamma',
    status: 'delivered',
    reportedAt: '10:05',
    deliveredAt: '10:25'
  },
  {
    id: 'THN-105',
    incidentId: 'INC-2026-01',
    tag: 'red',
    ageGroup: 'adult',
    gender: 'male',
    injuryDescription: 'Severe crush injury to pelvis with signs of hypovolemic shock',
    injuryDescriptionAr: 'إصابة هرسية شديدة بالحوض مع علامات صدمة نقص حجم الدم',
    respiratoryRate: 32,
    radialPulsePresent: false,
    mentalStatus: 'cannot_follow',
    requiredCapability: 'level1_trauma',
    status: 'field_triage',
    reportedAt: '10:24'
  }
];

export const INITIAL_PREDICTIONS: SurgePrediction[] = [
  {
    facilityId: 'fac-alfa',
    predictedSurgePercent: 28,
    timeframeMinutes: 45,
    confidencePercent: 89,
    cause: 'High egress pedestrian flow from Haram Central Courtyard following Zuhr prayer',
    causeAr: 'تدفق مشاة كثيف خارجين من صحن الحرم المكي الشريف عقب صلاة الظهر',
    recommendedIntervention: 'Redirect incoming low & moderate acuity cases to Delta Primary and Virtual Hub. Reserve Alfa strictly for Red Flag resuscitation.',
    recommendedInterventionAr: 'تفعيل إعادة توجيه الحالات المنخفضة والمتوسطة إلى مركز دلتا ومستشفى صحة الافتراضي، وحصر ألفا للحالات الحرجة فقط.'
  },
  {
    facilityId: 'fac-gamma',
    predictedSurgePercent: 18,
    timeframeMinutes: 60,
    confidencePercent: 74,
    cause: 'Elevated ambient temperature (42°C) triggering heat exhaustion spikes around Jamarat',
    causeAr: 'ارتفاع درجة الحرارة المحيطة (42 درجة) وتوقع زيادة حالات الإجهاد الحراري بمحيط الجمرات',
    recommendedIntervention: 'Deploy mobile hydration points and dispatch cooling misting carts to relieve station load.',
    recommendedInterventionAr: 'نشر نقاط الإرواء المتنقلة وعربات الرذاذ لتخفيف الضغط عن المركز.'
  }
];

export const ZONES = [
  { id: 'haram_plaza', name: 'Central Haram Plaza', nameAr: 'ساحات الحرم المكي المركزية' },
  { id: 'mina_valley', name: 'Mina Valley (Camp Areas)', nameAr: 'مشعر منى (مخيمات الحجاج)' },
  { id: 'jamarat_bridge', name: 'Jamarat Facility & Bridge', nameAr: 'منشأة جسر الجمرات' },
  { id: 'muzdalifah', name: 'Muzdalifah Gathering Area', nameAr: 'مشعر مزدلفة' },
  { id: 'arafat', name: 'Arafat Plains & Namirah', nameAr: 'صعيد عرفات ومسجد نمرة' },
  { id: 'aziziyah', name: 'Al-Aziziyah Commercial District', nameAr: 'حي العزيزية' },
  { id: 'madinah_central', name: 'Madinah Central Northern Area', nameAr: 'المنطقة المركزية - المدينة المنورة' },
];

export const SYMPTOMS_LIST = [
  { id: 'chest_pain', icon: 'HeartPulse', name: 'Chest Pain or Pressure', nameAr: 'ألم أو ضغط في الصدر', highRiskPotential: true },
  { id: 'breathing', icon: 'Wind', name: 'Difficulty Breathing / Wheezing', nameAr: 'صعوبة أو ضيق في التنفس', highRiskPotential: true },
  { id: 'heat_fever', icon: 'ThermometerSun', name: 'High Fever / Heat Stroke', nameAr: 'ارتفاع حرارة شديد أو ضربة شمس', highRiskPotential: true },
  { id: 'injury_trauma', icon: 'ShieldAlert', name: 'Physical Injury / Fall / Fracture', nameAr: 'إصابة جسدية / سقوط أو اشتباه كسر', highRiskPotential: true },
  { id: 'dizziness_faint', icon: 'Activity', name: 'Severe Dizziness / Fainting', nameAr: 'دوخة شديدة أو فقدان وعي مؤقت', highRiskPotential: true },
  { id: 'vomiting_diarrhea', icon: 'Droplets', name: 'Persistent Vomiting / Dehydration', nameAr: 'قيء مستمر أو جفاف حاد', highRiskPotential: false },
  { id: 'bleeding', icon: 'Flame', name: 'Uncontrolled Bleeding', nameAr: 'نزيف حاد مستمر', highRiskPotential: true },
  { id: 'mild_cold_throat', icon: 'Smile', name: 'Mild Sore Throat / Cold / Headache', nameAr: 'التهاب حلق خفيف / رشح أو صداع بسيط', highRiskPotential: false }
];
