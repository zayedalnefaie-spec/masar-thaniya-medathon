import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { PatientTriage } from './components/PatientTriage';
import { ThaniyaMCI } from './components/ThaniyaMCI';
import { CommandCenter } from './components/CommandCenter';
import { RoutingLab } from './components/RoutingLab';
import { NearbyFacilities } from './components/NearbyFacilities';
import { DigitalTwin3D } from './components/DigitalTwin3D';
import { JudgeDemoModal } from './components/JudgeDemoModal';
import { DirectionsModal } from './components/DirectionsModal';
import { Facility, Language, MCICasualty, CasualtyStatus } from './types';
import { INITIAL_FACILITIES, INITIAL_CASUALTIES } from './data/mockData';
import { TRANSLATIONS } from './data/translations';
import { ShieldCheck, Heart, Users, Sparkles, Building2, PhoneCall } from 'lucide-react';

export default function App() {
  const [currentLang, setCurrentLang] = useState<Language>('ar');
  const [activeTab, setActiveTab] = useState<string>('patient');
  const [facilities, setFacilities] = useState<Facility[]>(INITIAL_FACILITIES);
  const [casualties, setCasualties] = useState<MCICasualty[]>(INITIAL_CASUALTIES);
  const [isLoadBalancingApplied, setIsLoadBalancingApplied] = useState<boolean>(false);
  const [selectedDirectionFacility, setSelectedDirectionFacility] = useState<Facility | null>(null);
  const [isJudgeModalOpen, setIsJudgeModalOpen] = useState<boolean>(false);

  // Sync RTL / LTR document direction with language
  useEffect(() => {
    const isRtl = currentLang === 'ar' || currentLang === 'ur';
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = currentLang;
  }, [currentLang]);

  // Capacity update with reservation / handover logic
  const handleUpdateFacilityCapacity = (facilityId: string, occupiedDelta: number, reservedDelta: number) => {
    setFacilities(prev => prev.map(f => {
      if (f.id === facilityId) {
        return {
          ...f,
          occupiedBeds: Math.max(0, Math.min(f.totalBeds, f.occupiedBeds + occupiedDelta)),
          reservedBeds: Math.max(0, f.reservedBeds + reservedDelta),
          lastUpdatedMinutesAgo: 1
        };
      }
      return f;
    }));
  };

  // Toggle facility operational status for lab stress-testing
  const handleToggleFacilityStatus = (facilityId: string) => {
    setFacilities(prev => prev.map(f => {
      if (f.id === facilityId) {
        return {
          ...f,
          isOperational: !f.isOperational,
          erAccepting: !f.isOperational
        };
      }
      return f;
    }));
  };

  // Toggle capability
  const handleToggleCapability = (facilityId: string, capability: string) => {
    setFacilities(prev => prev.map(f => {
      if (f.id === facilityId) {
        const has = f.capabilities.includes(capability);
        return {
          ...f,
          capabilities: has ? f.capabilities.filter(c => c !== capability) : [...f.capabilities, capability]
        };
      }
      return f;
    }));
  };

  const handleResetFacilities = () => {
    setFacilities(INITIAL_FACILITIES);
    setCasualties(INITIAL_CASUALTIES);
    setIsLoadBalancingApplied(false);
  };

  const handleAddCasualty = (casualty: MCICasualty) => {
    setCasualties(prev => [casualty, ...prev]);
  };

  const handleUpdateCasualtyStatus = (casualtyId: string, status: CasualtyStatus, facilityId?: string) => {
    setCasualties(prev => prev.map(c => {
      if (c.id === casualtyId) {
        return {
          ...c,
          status,
          assignedFacilityId: facilityId || c.assignedFacilityId,
          enRouteAt: status === 'en_route' ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : c.enRouteAt,
          deliveredAt: status === 'delivered' ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : c.deliveredAt
        };
      }
      return c;
    }));
  };

  const handleApplyLoadBalancing = () => {
    setIsLoadBalancingApplied(!isLoadBalancingApplied);
    // Dynamically transfer 12 low acuity loads from Alfa to Delta and Virtual
    setFacilities(prev => prev.map(f => {
      if (f.id === 'fac-alfa') {
        return { ...f, occupiedBeds: isLoadBalancingApplied ? 110 : 96 }; // drops from 92% to 80%
      }
      if (f.id === 'fac-delta') {
        return { ...f, occupiedBeds: isLoadBalancingApplied ? 16 : 28 };
      }
      return f;
    }));
  };

  const handleSelectJudgeScenario = (scenarioId: string) => {
    if (scenarioId === 'scenario_high_risk' || scenarioId === 'scenario_low_acuity') {
      setActiveTab('patient');
    } else if (scenarioId === 'scenario_mci_thaniya') {
      setActiveTab('mci');
    } else if (scenarioId === 'scenario_command_lab') {
      setActiveTab('command');
      handleApplyLoadBalancing();
    } else if (scenarioId === 'scenario_twin_3d') {
      setActiveTab('twin3d');
    }
  };

  const t = TRANSLATIONS[currentLang];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Header */}
      <Header
        currentLang={currentLang}
        onLanguageChange={setCurrentLang}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenDemoModal={() => setIsJudgeModalOpen(true)}
      />

      {/* Main Content Body */}
      <main className="flex-1 pb-16">
        {activeTab === 'patient' && (
          <PatientTriage
            currentLang={currentLang}
            facilities={facilities}
            onOpenDirections={setSelectedDirectionFacility}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'mci' && (
          <ThaniyaMCI
            currentLang={currentLang}
            facilities={facilities}
            casualties={casualties}
            onAddCasualty={handleAddCasualty}
            onUpdateCasualtyStatus={handleUpdateCasualtyStatus}
            onUpdateFacilityCapacity={handleUpdateFacilityCapacity}
          />
        )}

        {activeTab === 'command' && (
          <CommandCenter
            currentLang={currentLang}
            facilities={facilities}
            onApplyLoadBalancing={handleApplyLoadBalancing}
            isLoadBalancingApplied={isLoadBalancingApplied}
          />
        )}

        {activeTab === 'twin3d' && (
          <DigitalTwin3D
            currentLang={currentLang}
            facilities={facilities}
            onOpenDirections={setSelectedDirectionFacility}
          />
        )}

        {activeTab === 'lab' && (
          <RoutingLab
            currentLang={currentLang}
            facilities={facilities}
            onToggleFacilityStatus={handleToggleFacilityStatus}
            onToggleCapability={handleToggleCapability}
            onResetFacilities={handleResetFacilities}
          />
        )}

        {activeTab === 'nearby' && (
          <NearbyFacilities
            currentLang={currentLang}
            facilities={facilities}
            onOpenDirections={setSelectedDirectionFacility}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-xs py-8 px-4 text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1.5 text-center md:text-right">
            <div className="flex items-center justify-center md:justify-start gap-2">
              <span className="font-black text-white text-sm">مسار Health | Masar</span>
              <span className="text-teal-400 font-bold">+ ثانية | Thaniya</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-teal-500/10 text-teal-300 border border-teal-500/30">
                MEDATHON 2026
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              فريق FlowCare: Ola Mustafa Alhashim • غيداء عمر الشريف • Alanoud Khalid Albanna • Zayed Mohameed alnefaie
            </p>
          </div>

          <div className="text-center md:text-left text-[11px] text-slate-500 max-w-md">
            {t.prototypeNotice}
          </div>
        </div>
      </footer>

      {/* Judge Demo Walkthrough Modal */}
      <JudgeDemoModal
        isOpen={isJudgeModalOpen}
        onClose={() => setIsJudgeModalOpen(false)}
        onSelectScenario={handleSelectJudgeScenario}
      />

      {/* Directions Modal */}
      <DirectionsModal
        facility={selectedDirectionFacility}
        onClose={() => setSelectedDirectionFacility(null)}
        currentLang={currentLang}
      />
    </div>
  );
}
